package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class FabricaBanco {
    
    private static Connection con;
    
    public static Connection getConexao(){
        
        if(con == null){
        
            try {
                
                con = DriverManager.getConnection("jdbc:postgresql://200.18.128.54/aula", "aula", "aula");
                //con = DriverManager.getConnection("jdbc:postgresql://10.90.24.54/aula", "aula", "aula");

            } catch (SQLException err) {
                
                JOptionPane.showMessageDialog(null, "Erro no momento da conexão com o banco: " + err.getMessage(), "Status da conexão", JOptionPane.WARNING_MESSAGE);

            }
        
        }
        
        return con;
        
        /*if(con == null){
        
            try {

                con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Gerenciamento_de_Barbearia_BD", "postgres", "postgres");

            } catch (SQLException err) {
                err.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erro no momento da conexão com o banco", "Status da conexão", JOptionPane.WARNING_MESSAGE);

            }
        
        }
        
        return con;*/
        
    }
    
}
