package repository;

import main.FabricaBanco;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelos.Pagamento;

public class PagamentoDAO {
    
    //DAO -> sigla para Data Access Object
    
    //metodo para inserir
    public static boolean inserirPagamento(Pagamento e){
        
        try {
            String SQL1 = "INSERT INTO \"Gerenciamento_de_Barbearia_BD\".\"Pagamento\""
                    + "(data, \"nomeCliente\", estado, valor, \"formaPagamento\")"
                    + "Values(?, ?, ?, ?, ?);";
            
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement ps1 = conexao.prepareStatement(SQL1);
            ps1.setTimestamp(1, new Timestamp(e.getData().getTime()));
            ps1.setString(2, e.getNomeCliente());
            ps1.setBoolean(3, e.isEstado());
            ps1.setDouble(4, e.getValor());
            ps1.setString(5, e.getFormaPag());
            
            ps1.executeUpdate();
            
            return true;
            
        } catch (SQLException ex) {
            
            Logger.getLogger(PagamentoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return false;
        
    }
    
    // -----> SELECT
    // -----> depois faremos o UPDATE
    
    public static Vector<Pagamento> consultaPagamento(){
        
        Vector<Pagamento> retorno = null;
        
        try {
            
            retorno =  new Vector<Pagamento>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT * FROM \"Gerenciamento_de_Barbearia_BD\".\"Pagamento\" ORDER BY data";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Pagamento atual = new Pagamento();
                atual.setData(r.getTimestamp("data"));
                atual.setNomeCliente(r.getString("nomeCliente"));
                atual.setEstado(r.getBoolean("estado"));
                atual.setValor(r.getDouble("valor"));
                atual.setFormaPag(r.getString("formaPagamento"));
                retorno.add(atual);
                
            }
            
        } catch (SQLException ex) {
            
            Logger.getLogger(PagamentoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return retorno;
        
    }
    
    public Vector<Pagamento> RelatorioGeral(){
        
        Vector<Pagamento> retorno = null;
        
        try{
            
            retorno = new Vector<Pagamento>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT data, valor, formaPag FROM \"Gerenciamento_de_Barbearia_BD\".\"Pagamento\" ORDER BY valor";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Pagamento atual = new Pagamento();
                atual.setData(r.getTimestamp("data"));
                atual.setNomeCliente(r.getString("nome"));
                atual.setEstado(r.getBoolean("estado"));
                atual.setValor(r.getDouble("valor"));
                atual.setFormaPag(r.getString("formaPag"));
                retorno.add(atual);
                
            }
            
        }catch(SQLException ex){
            
            Logger.getLogger(PagamentoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
            return null;
            
        }
        
        return retorno;
    }
    
    public static void updatePagamento(Pagamento pagamento) {
        
        String sql = "UPDATE \"Gerenciamento_de_Barbearia_BD\".\"Pagamento\" SET data=?, estado=?, valor=?, \"formaPagamento\"=?, \"nomeCliente\"=? "
                + "WHERE data=?";

        Connection conexao = FabricaBanco.getConexao();

        try {
            
            PreparedStatement tran = conexao.prepareStatement(sql);
            
            tran.setTimestamp(1, new Timestamp(pagamento.getData().getTime()));
            tran.setBoolean(2, pagamento.isEstado());
            tran.setDouble(3, pagamento.getValor());
            tran.setString(4, pagamento.getFormaPag());
            tran.setString(5, pagamento.getNomeCliente());
            tran.setDate(6, new Date(pagamento.getData().getTime()));

            int tuplasModificadas = tran.executeUpdate();

        //retornar sucesso verificando a variavel tuplasModificadas
        } catch (SQLException e) {
            
            e.printStackTrace();
            
        }
        
    }
    
    public static boolean deletaPagamento(Pagamento f) {

        try {

            String SQL1 = "DELETE FROM \"Gerenciamento_de_Barbearia_BD\".\"Pagamento\""
                    + "WHERE data=?;";

            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement transacao = conexao.prepareStatement(SQL1);
            transacao.setTimestamp(1, f.getData());

            transacao.execute();

            return true;

        } catch (SQLException ex) {

            Logger.getLogger(PagamentoDAO.class.getName()).log(Level.SEVERE, null, ex);

        }

        return false;

    }
    
}
