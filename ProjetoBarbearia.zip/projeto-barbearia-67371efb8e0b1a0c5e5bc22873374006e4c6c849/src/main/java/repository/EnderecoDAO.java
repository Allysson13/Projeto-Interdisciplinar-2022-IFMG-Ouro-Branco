package repository;

import main.FabricaBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelos.Endereco;

public class EnderecoDAO {
    
    //DAO -> sigla para Data Access Object
    
    //metodo para inserir
    public static boolean inserirEndereco(Endereco e){
        
        try {
            
            String SQL1 = "INSERT INTO \"Gerenciamento_de_Barbearia_BD\".\"Endereco\""
                    + "(id, cep, bairro, numero)"
                    + "Values(?, ?, ?, ?);";
            
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement ps1 = conexao.prepareStatement(SQL1);
            ps1.setInt(1, e.getId());
            ps1.setString(2, e.getCep());
            ps1.setString(2, e.getBairro());
            ps1.setString(2, e.getNumero());
            
            ps1.executeUpdate();
            
            return true;
            
        } catch (SQLException ex) {
            
            Logger.getLogger(EnderecoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return false;
        
    }
    
    // -----> SELECT
    // -----> depois faremos o UPDATE
    
    public static Vector<Endereco> consultaEndereco(){
        
        Vector<Endereco> retorno = null;
        
        try {
            
            retorno =  new Vector<Endereco>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT * FROM \"Gerenciamento_de_Barbearia_BD\".\"Endereco\" ORDER BY  bairro";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Endereco atual = new Endereco();
                atual.setId(r.getInt("id"));
                atual.setCep(r.getString("cep"));
                atual.setBairro(r.getString("bairro"));
                atual.setNumero(r.getString("numero"));
                retorno.add(atual);
                
            }
            
        } catch (SQLException ex) {
            
            Logger.getLogger(EnderecoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return retorno;
        
    }
    
    public Vector<Endereco> RelatorioGeral(){
        
        Vector<Endereco> retorno = null;
        
        try{
            
            retorno = new Vector<Endereco>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT id FROM \"Gerenciamento_de_Barbearia_BD\".\"Endereco\" GROUP BY cep";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Endereco atual = new Endereco();
                atual.setId(r.getInt("id"));
                atual.setCep(r.getString("cep"));
                atual.setBairro(r.getString("bairro"));
                atual.setNumero(r.getString("numero"));
                retorno.add(atual);
                
            }
            
        }catch(SQLException ex){
            
            Logger.getLogger(EnderecoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
            return null;
            
        }
        
        return retorno;
    }
    
    public static void updateEndereco(Endereco endereco) {
        
        String sql = "UPDATE \"Gerenciamento_de_Barbearia_BD\".\"Endereco\" SET cep=?, bairro=?, numero=? "
                + "WHERE id=?";

        Connection conexao = FabricaBanco.getConexao();

        try {
            
            PreparedStatement tran = conexao.prepareStatement(sql);
            
            tran.setString(1, endereco.getCep());
            tran.setString(2, endereco.getBairro());
            tran.setString(3, endereco.getNumero());
            tran.setInt(4, endereco.getId());

            int tuplasModificadas = tran.executeUpdate();

        } catch (SQLException e) {
            
            e.printStackTrace();
            
        }
        
    }
    
    public static boolean deletaEndereco(Endereco f) {

        try {

            String SQL1 = "DELETE FROM \"Gerenciamento_de_Barbearia_BD\".\"Endereco\""
                    + "WHERE id=?;";

            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement transacao = conexao.prepareStatement(SQL1);
            transacao.setInt(1, f.getId());

            transacao.execute();

            return true;

        } catch (SQLException ex) {

            Logger.getLogger(EnderecoDAO.class.getName()).log(Level.SEVERE, null, ex);

        }

        return false;

    }
    
}
