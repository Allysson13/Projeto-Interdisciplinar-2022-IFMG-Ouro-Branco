package repository;

import main.FabricaBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelos.ContaBancaria;

public class ContaBancariaDAO {
    
    //DAO -> sigla para Data Access Object
    
    //metodo para inserir
    public static boolean inserirContaBancaria(ContaBancaria cb){
        
        try {
            
            String SQL1 = "INSERT INTO \"Gerenciamento_de_Barbearia_BD\".\"ContaBancaria\""
                    + "(codigo, agencia, \"nomeTitular\")"
                    + "Values(?, ?, ?);";
            
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement ps1 = conexao.prepareStatement(SQL1);
            ps1.setString(1, cb.getCodigo());
            ps1.setString(2, cb.getAgencia());
            ps1.setString(2, cb.getNomeTitular());
            
            ps1.executeUpdate();
            
            return true;
            
        } catch (SQLException ex) {
            
            Logger.getLogger(ContaBancariaDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return false;
        
    }
    
    // -----> SELECT
    // -----> depois faremos o UPDATE
    
    public static Vector<ContaBancaria> consultaContaBancaria(){
        
        Vector<ContaBancaria> retorno = null;
        
        try {
            
            retorno =  new Vector<ContaBancaria>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT * FROM \"Gerenciamento_de_Barbearia_BD\".\"ContaBancaria\" ORDER BY \"nomeTitular\"";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                ContaBancaria atual = new ContaBancaria();
                atual.setCodigo(r.getString("codigo"));
                atual.setAgencia(r.getString("agencia"));
                atual.setNomeTitular(r.getString("nomeTitular"));
                retorno.add(atual);
                
            }
            
        } catch (SQLException ex) {
            
            Logger.getLogger(ContaBancariaDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return retorno;
        
    }
    
    public Vector<ContaBancaria> RelatorioAgencias(){
        
        Vector<ContaBancaria> retorno = null;
        
        try{
            
            retorno = new Vector<ContaBancaria>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT nome, codigo FROM \"Gerenciamento_de_Barbearia_BD\".\"ContaBancaria\" GROUP BY  agencia";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                ContaBancaria atual = new ContaBancaria();
                atual.setCodigo(r.getString("codigo"));
                atual.setAgencia(r.getString("agencia"));
                atual.setNomeTitular(r.getString("nome"));
                retorno.add(atual);
                
            }
            
        }catch(SQLException ex){
            
            Logger.getLogger(ContaBancariaDAO.class.getName()).log(Level.SEVERE, null, ex);
            
            return null;
            
        }
        
        return retorno;
    }
    
    public static void updateServico(ContaBancaria contaBancaria) {
        
        String sql = "UPDATE \"Gerenciamento_de_Barbearia_BD\".\"ContaBancaria\" SET agencia=?, \"nomeTitular\"=? "
                + "WHERE codigo=?";

        Connection conexao = FabricaBanco.getConexao();

        try {
            
            PreparedStatement tran = conexao.prepareStatement(sql);
            
            tran.setString(1, contaBancaria.getAgencia());
            tran.setString(2, contaBancaria.getNomeTitular());
            tran.setString(3, contaBancaria.getCodigo());

            int tuplasModificadas = tran.executeUpdate();

        //retornar sucesso verificando a variavel tuplasModificadas
        } catch (SQLException e) {
            
            e.printStackTrace();
            
        }
        
    }
    
    public static boolean deletaContaBancaria(ContaBancaria cb) {

        try {

            String SQL1 = "DELETE FROM \"Gerenciamento_de_Barbearia_BD\".\"ContaBancaria\""
                    + "WHERE codigo=?;";

            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement transacao = conexao.prepareStatement(SQL1);
            transacao.setString(1, cb.getCodigo());

            transacao.execute();

            return true;

        } catch (SQLException ex) {

            Logger.getLogger(ContaBancariaDAO.class.getName()).log(Level.SEVERE, null, ex);

        }

        return false;

    }
    
}