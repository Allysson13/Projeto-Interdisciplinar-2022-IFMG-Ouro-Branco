package repository;

import main.FabricaBanco;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import modelos.Agendamento;

public class AgendamentoDAO {
    
    //DAO -> sigla para Data Access Object
    
    //metodo para inserir
    public static boolean inserirAtendimento(Agendamento a){
        
        try {
            
            String SQL1 = "INSERT INTO \"Gerenciamento_de_Barbearia_BD\".\"Agendamento\""
                    + "(data, \"tipoServico\", valor, \"nomeCliente\")"
                    + "Values(?, ?, ?, ?);";
            
            System.out.println("");
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement ps1 = conexao.prepareStatement(SQL1);
            ps1.setTimestamp(1, new Timestamp(a.getData().getTime()));
            ps1.setString(2, a.getTipoServico());
            ps1.setDouble(3, a.getValor());
            ps1.setString(4, a.getNomeCliente());
            
            ps1.executeUpdate();
            
            return true;
            
        } catch (SQLException ex) {
            
            Logger.getLogger(AgendamentoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return false;
        
    }
    
    // -----> SELECT
    // -----> depois faremos o UPDATE
    
    public static Vector<Agendamento> consultaAgendamento(){
        
        Vector<Agendamento> retorno = null;
        
        try {
            
            retorno =  new Vector<>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT * FROM \"Gerenciamento_de_Barbearia_BD\".\"Agendamento\" ORDER BY data";
            //String SQL = "SELECT * FROM agendamento ORDER BY data";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Agendamento atual = new Agendamento();
                atual.setData((r.getTimestamp("data")));
                atual.setTipoServico(r.getString("tipoServico"));
                atual.setValor(r.getDouble("valor"));
                atual.setNomeCliente(r.getString("nomeCliente"));
                retorno.addElement(atual);
                
            }
            
        } catch (SQLException ex) {
            
            Logger.getLogger(AgendamentoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return retorno;
        
    }
    
    public DefaultListModel<Agendamento> RelatorioDiario(){
        
        DefaultListModel<Agendamento> retorno = null;
        
        try{
            
            retorno = new DefaultListModel<>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT data, tipoServico, valor, nomeCliente FROM \"Gerenciamento_de_Barbearia_BD\".\"Agendamento\" GROUP BY A.data";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Agendamento atual = new Agendamento();
                atual.setData(r.getTimestamp("data"));
                atual.setTipoServico(r.getString("tipoServico"));
                atual.setValor(r.getDouble("valor"));
                atual.setNomeCliente(r.getString("nomeCliente"));
                retorno.addElement(atual);
                
            }
            
        }catch(SQLException ex){
            
            Logger.getLogger(AgendamentoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
            return null;
            
        }
        
        return retorno;
        
    }
    
    public static void updateAgendamento(Agendamento agendamento) {
        
        String sql = "UPDATE \"Gerenciamento_de_Barbearia_BD\".\"Agendamento\" SET data=?, valor=?, \"nomeCliente\"=? "
                + "WHERE \"tipoServico\"=?";

        Connection conexao = FabricaBanco.getConexao();

        try {
            
            PreparedStatement tran = conexao.prepareStatement(sql);
            
            tran.setDate(1, new Date(agendamento.getData().getTime()));
            tran.setDouble(2, agendamento.getValor());
            tran.setString(3, agendamento.getNomeCliente());
            tran.setString(4, agendamento.getTipoServico());

            int tuplasModificadas = tran.executeUpdate();

        //retornar sucesso verificando a variavel tuplasModificadas
        } catch (SQLException e) {
            
            e.printStackTrace();
            
        }
        
    }
    
    public static boolean deletaAgendamento(Agendamento a) {

        try {

            String SQL1 = "DELETE FROM \"Gerenciamento_de_Barbearia_BD\".\"Agendamento\""
                    + "WHERE data=?;";

            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement transacao = conexao.prepareStatement(SQL1);
            transacao.setTimestamp(1, a.getData());

            transacao.execute();

            return true;

        } catch (SQLException ex) {

            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);

        }

        return false;

    }
    
}
