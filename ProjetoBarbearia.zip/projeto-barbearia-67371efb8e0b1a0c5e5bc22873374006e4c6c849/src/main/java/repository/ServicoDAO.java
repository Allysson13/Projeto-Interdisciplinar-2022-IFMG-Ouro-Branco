package repository;

import main.FabricaBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelos.Servico;

public class ServicoDAO {
    
    //DAO -> sigla para Data Access Object
    
    //metodo para inserir
    public static boolean inserirEndereco(Servico e){
        
        try {
            
            String SQL1 = "INSERT INTO \"Gerenciamento_de_Barbearia_BD\".\"Servico\""
                    + "(produtos, tipoServico, manutencao, modalidade)"
                    + "Values(?, ?, ?, ?);";
            
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement ps1 = conexao.prepareStatement(SQL1);
            ps1.setString(1, e.getProdutos());
            ps1.setString(2, e.getTipoServico());
            ps1.setString(3, e.getManutencao());
            ps1.setString(4, e.getModalidade());
            
            ps1.executeUpdate();
            
            return true;
            
        } catch (SQLException ex) {
            
            Logger.getLogger(ServicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return false;
        
    }
    
    // -----> SELECT
    // -----> depois faremos o UPDATE
    
    public static Vector<Servico> consultaServico(){
        
        Vector<Servico> retorno = null;
        
        try {
            
            retorno =  new Vector<Servico>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT * FROM \"Gerenciamento_de_Barbearia_BD\".\"Servico\" ORDER BY modalidade";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Servico atual = new Servico();
                atual.setProdutos(r.getString("produtos"));
                atual.setTipoServico(r.getString("tipoServico"));
                atual.setManutencao(r.getString("manutencao"));
                atual.setModalidade(r.getString("modalidade"));
                retorno.add(atual);
                
            }
            
        } catch (SQLException ex) {
            
            Logger.getLogger(ServicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return retorno;
        
    }
    
    public Vector<Servico> RelatorioModalidade(){
        
        Vector<Servico> retorno = null;
        
        try{
            
            retorno = new Vector<Servico>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT produtos, manutencao, modalidade FROM \"Gerenciamento_de_Barbearia_BD\".\"Servico\" GROUP BY modalidade";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Servico atual = new Servico();
                atual.setProdutos(r.getString("produtos"));
                atual.setTipoServico(r.getString("tipoServico"));
                atual.setManutencao(r.getString("manutencao"));
                atual.setModalidade(r.getString("modalidade"));
                retorno.add(atual);
                
            }
            
        }catch(SQLException ex){
            
            Logger.getLogger(ServicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
            return null;
            
        }
        
        return retorno;
    }
    
    public static void updateServico(Servico servico) {
        
        String sql = "UPDATE \"Gerenciamento_de_Barbearia_BD\".\"Servico\" SET produtos=?, manutencao=?, modalidade=? "
                + "WHERE tipoServico=?";

        Connection conexao = FabricaBanco.getConexao();

        try {
            
            PreparedStatement tran = conexao.prepareStatement(sql);
            
            tran.setString(1, servico.getProdutos());
            tran.setString(2, servico.getManutencao());
            tran.setString(3, servico.getModalidade());
            tran.setString(4, servico.getTipoServico());

            int tuplasModificadas = tran.executeUpdate();

        //retornar sucesso verificando a variavel tuplasModificadas
        } catch (SQLException e) {
            
            e.printStackTrace();
            
        }
        
    }
    
    public static boolean deletaServico(Servico s) {

        try {

            String SQL1 = "DELETE FROM \"Gerenciamento_de_Barbearia_BD\".\"Servico\""
                    + "WHERE tipoServico=?;";

            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement transacao = conexao.prepareStatement(SQL1);
            transacao.setString(1, s.getTipoServico());

            transacao.execute();

            return true;

        } catch (SQLException ex) {

            Logger.getLogger(ServicoDAO.class.getName()).log(Level.SEVERE, null, ex);

        }

        return false;

    }
    
}
