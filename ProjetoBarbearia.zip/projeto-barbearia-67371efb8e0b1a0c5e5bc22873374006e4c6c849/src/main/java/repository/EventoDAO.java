package repository;

import main.FabricaBanco;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelos.Evento;

public class EventoDAO {
    
    //DAO -> sigla para Data Access Object
    
    //metodo para inserir
    public static boolean inserirEvento(Evento e){
        
        try {
            String SQL1 = "INSERT INTO \"Gerenciamento_de_Barbearia_BD\".\"Evento\""
                    + "(\"nomeConvidados\", fotografo, duracao, data, cenario, alimentacao)"
                    + "Values(?, ?, ?, ?, ?, ?);";
            
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement ps1 = conexao.prepareStatement(SQL1);
            ps1.setString(1, e.getNomeConvidados());
            ps1.setString(2, e.getFotografo());
            ps1.setDouble(3, e.getDuracao());
            ps1.setDate(4, new Date(e.getData().getTime()));
            ps1.setString(5, e.getCenario());
            ps1.setString(6, e.getAlimentacao());
            
            ps1.executeUpdate();
            
            return true;
            
        } catch (SQLException ex) {
            
            Logger.getLogger(EventoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return false;
        
    }
    
    // -----> SELECT
    // -----> depois faremos o UPDATE
    
    public static Vector<Evento> consultaEvento(){
        
        Vector<Evento> retorno = null;
        
        try {
            
            retorno =  new Vector<Evento>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT * FROM \"Gerenciamento_de_Barbearia_BD\".\"Evento\" ORDER BY data";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Evento atual = new Evento();
                atual.setNomeConvidados(r.getString("nomeConvidados"));
                atual.setFotografo(r.getString("fotografo"));
                atual.setDuracao(r.getDouble("duracao"));
                atual.setData(r.getTimestamp("data"));
                atual.setCenario(r.getString("cenario"));
                atual.setAlimentacao(r.getString("alimentacao"));
                retorno.add(atual);
                
            }
            
        } catch (SQLException ex) {
            
            Logger.getLogger(EventoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return retorno;
        
    }
    
    public Vector<Evento> RelatorioCustos(){
        
        Vector<Evento> retorno = null;
        
        try{
            
            retorno = new Vector<Evento>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT cenario, alimentacao, duracao FROM \"Gerenciamento_de_Barbearia_BD\".\"Evento\" GROUP BY alimentacao";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Evento atual = new Evento();
                atual.setNomeConvidados(r.getString("nomeConvidados"));
                atual.setFotografo(r.getString("fotografo"));
                atual.setDuracao(r.getDouble("duracao"));
                atual.setData(r.getTimestamp("data"));
                atual.setCenario(r.getString("cenario"));
                atual.setAlimentacao(r.getString("alimentacao"));
                retorno.add(atual);
                
            }
            
        }catch(SQLException ex){
            
            Logger.getLogger(EventoDAO.class.getName()).log(Level.SEVERE, null, ex);
            
            return null;
            
        }
        
        return retorno;
    }
    
    public static void updateEvento(Evento evento) {
        
        String sql = "UPDATE \"Gerenciamento_de_Barbearia_BD\".\"Evento\" "
                + "SET \"nomeConvidados\"=?, fotografo=?, duracao=?, data=?, cenario=?, alimentacao=? "
                + "WHERE data=?";

        Connection conexao = FabricaBanco.getConexao();

        try {
            
            PreparedStatement tran = conexao.prepareStatement(sql);
            
            tran.setString(1, evento.getNomeConvidados());
            tran.setString(2, evento.getFotografo());
            tran.setDouble(3, evento.getDuracao());
            tran.setDate(4, new Date(evento.getData().getTime()));
            tran.setString(5, evento.getCenario());
            tran.setString(6, evento.getAlimentacao());
            tran.setDate(7, new Date(evento.getData().getTime()));

            int tuplasModificadas = tran.executeUpdate();
            
        } catch (SQLException e) {
            
            e.printStackTrace();
            
        }
        
    }
    
    public static boolean deletaEvento(Evento f) {

        try {

            String SQL1 = "DELETE FROM \"Gerenciamento_de_Barbearia_BD\".\"Evento\""
                    + "WHERE data=?;";

            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement transacao = conexao.prepareStatement(SQL1);
            transacao.setTimestamp(1, f.getData());

            transacao.execute();

            return true;

        } catch (SQLException ex) {

            Logger.getLogger(EventoDAO.class.getName()).log(Level.SEVERE, null, ex);

        }

        return false;

    }
    
}
