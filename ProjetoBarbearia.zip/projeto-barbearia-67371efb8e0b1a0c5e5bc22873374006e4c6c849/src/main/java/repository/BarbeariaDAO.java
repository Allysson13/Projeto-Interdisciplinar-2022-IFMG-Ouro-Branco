package repository;

import main.FabricaBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelos.Barbearia;

public class BarbeariaDAO {
    
    //DAO -> sigla para Data Access Object
    
    //metodo para inserir
    public static boolean inserirAtendimento(Barbearia b){
        
        try {
            
            String SQL1 = "INSERT INTO \"Gerenciamento_de_Barbearia_BD\".\"Barbearia\""
                    + "(id, nomeGerente)"
                    + "Values(?, ?);";
            
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement ps1 = conexao.prepareStatement(SQL1);
            ps1.setString(1, b.getId());
            ps1.setString(2, b.getNomeGerente());
            
            ps1.executeUpdate();
            
            return true;
            
        } catch (SQLException ex) {
            
            Logger.getLogger(BarbeariaDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return false;
        
    }
    
    // -----> SELECT
    // -----> depois faremos o UPDATE
    
    public static Vector<Barbearia> consultaBarbearia(){
        
        Vector<Barbearia> retorno = null;
        
        try {
            
            retorno =  new Vector<Barbearia>();
            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            String SQL = "SELECT * FROM \"Gerenciamento_de_Barbearia_BD\".\"Barbearia\" ORDER BY nomeGerente";
            PreparedStatement ps = conexao.prepareStatement(SQL);
            ResultSet r = ps.executeQuery();
            
            while(r.next()){
                
                Barbearia atual = new Barbearia();
                atual.setId(r.getString("id"));
                atual.setNomeGerente(r.getString("nomeGerente"));
                retorno.add(atual);
                
            }
            
        } catch (SQLException ex) {
            
            Logger.getLogger(BarbeariaDAO.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        return retorno;
        
    }
    
    public static void updateBarbearia(Barbearia barbearia) {

        String sql = "UPDATE \"Gerenciamento_de_Barbearia_BD\".\"Barbearia\" SET nomeGerente=?" + "WHERE id=?";

        Connection conexao = FabricaBanco.getConexao();

        try {

            PreparedStatement tran = conexao.prepareStatement(sql);
            
            tran.setString(1, barbearia.getNomeGerente());
            tran.setString(2, barbearia.getId());

            int tuplasModificadas = tran.executeUpdate();

            //retornar sucesso verificando a variavel tuplasModificadas
        } catch (SQLException e) {

            e.printStackTrace();

        }

    }
    
    public static boolean deletaBarbearia(Barbearia f) {

        try {

            String SQL1 = "DELETE FROM \"Gerenciamento_de_Barbearia_BD\".\"Barbearia\""
                    + "WHERE id=?;";

            FabricaBanco c = new FabricaBanco();
            Connection conexao = c.getConexao();
            PreparedStatement transacao = conexao.prepareStatement(SQL1);
            transacao.setString(1, f.getId());

            transacao.execute();

            return true;

        } catch (SQLException ex) {

            Logger.getLogger(BarbeariaDAO.class.getName()).log(Level.SEVERE, null, ex);

        }

        return false;

    }
    
}
