package tabelas;

import controller.RegraTabelaAgendamento;

public class TabelaAgendamento extends javax.swing.JPanel {
    
    private RegraTabelaAgendamento minhasRegras;

    public TabelaAgendamento() {
        
        initComponents();
        
        this.minhasRegras = new RegraTabelaAgendamento();
        tabelaAgendamento.setModel(this.minhasRegras);
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaAgendamento = new javax.swing.JTable();
        botaoDeletar = new javax.swing.JButton();

        setBackground(new java.awt.Color(0, 51, 102));

        tabelaAgendamento.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelaAgendamento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tabelaAgendamentoKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tabelaAgendamento);

        botaoDeletar.setBackground(new java.awt.Color(0, 0, 204));
        botaoDeletar.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        botaoDeletar.setForeground(new java.awt.Color(0, 255, 255));
        botaoDeletar.setText("Deletar");
        botaoDeletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoDeletarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 840, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botaoDeletar)
                .addGap(389, 389, 389))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 528, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botaoDeletar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void botaoDeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoDeletarActionPerformed
        
        this.minhasRegras.removeLinha();
        
    }//GEN-LAST:event_botaoDeletarActionPerformed

    private void tabelaAgendamentoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tabelaAgendamentoKeyReleased
        
        if (evt.getKeyChar() == 127) {

            botaoDeletar.doClick();

        }
        
    }//GEN-LAST:event_tabelaAgendamentoKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoDeletar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaAgendamento;
    // End of variables declaration//GEN-END:variables
}
