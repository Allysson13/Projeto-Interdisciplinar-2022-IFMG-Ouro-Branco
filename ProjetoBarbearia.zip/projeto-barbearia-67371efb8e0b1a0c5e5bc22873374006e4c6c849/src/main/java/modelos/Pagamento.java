package modelos;

import java.sql.Timestamp;
import java.util.Date;

public class Pagamento {
    
    //atributos
    
    private Timestamp data;
    private String nomeCliente;
    private boolean estado;
    private double valor;
    private String formaPag;
    
    //construtores

    public Pagamento() {
        
    }

    public Pagamento(Timestamp data, String nome, boolean estado, double valor, String formaPag) {
        this.data = data;
        this.nomeCliente = nome;
        this.estado = estado;
        this.valor = valor;
        this.formaPag = formaPag;
    }
    
    //encapsulamento

    public Timestamp getData() {
        return data;
    }

    public void setData(Timestamp data) {
        this.data = data;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getFormaPag() {
        return formaPag;
    }

    public void setFormaPag(String formaPag) {
        this.formaPag = formaPag;
    }
    
    //construtores
    
    //toSring

    @Override
    public String toString() {
        
        return "Data=" + this.data + ", Nome: " + this.nomeCliente + ", Comprovante: " + this.estado + ", Valor: " + this.valor + ", Forma de Pagamento"
                + "" + this.formaPag;
    
    }
    
}
