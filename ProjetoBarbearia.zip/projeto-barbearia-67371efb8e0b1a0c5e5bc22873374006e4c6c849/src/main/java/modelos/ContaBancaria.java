package modelos;

public class ContaBancaria {
    
    //atributos
    
    private String codigo;
    private String agencia;
    private String nomeTitular;
    
    //construtores

    public ContaBancaria() {
        
    }

    public ContaBancaria(String codigo, String agencia, String nome) {
        this.codigo = codigo;
        this.agencia = agencia;
        this.nomeTitular = nome;
    }
    
    //encapsulamento

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getNomeTitular() {
        return nomeTitular;
    }

    public void setNomeTitular(String nomeTitular) {
        this.nomeTitular = nomeTitular;
    }
    
    //comportamenetos
    
    //toString

    @Override
    public String toString() {
        
        return "Codigo: " + this.codigo + ", Agencia: " + this.agencia + ", Nome: " + this.nomeTitular;
        
    }
    
    
    
}
