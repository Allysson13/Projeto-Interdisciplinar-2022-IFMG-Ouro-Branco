package controller;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Gerente;
import modelos.Usuario;
import repository.GerenteDAO;
import repository.UsuarioDAO;
import telas.Login;

public class RegraTabelaGerente extends AbstractTableModel {
    
    private Vector<Gerente> vetGerente = GerenteDAO.consultaGerente();
    private Vector<Usuario> vetUsuario = UsuarioDAO.consultaUsuarioGerente();
    private String nomeColunnas[] = {"Código", "Nome", "Idade", "Senha", "Email", "Tipo Usuário", "CPF"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaUsuarioCliente(Usuario usuario, Gerente gerente){
        
        if(usuario != null && usuario.getCodigo() != 0){
            
            UsuarioDAO.updateUsuario(usuario);
            GerenteDAO.updateGerente(gerente);
            /*FramePrincipal framePai = new FramePrincipal();
            framePai.trocarPainel(null);*/
            
        }
        
    }

    @Override
    public int getRowCount() {
        
        return this.vetGerente.size();
        
    }

    @Override
    public int getColumnCount() {
        
        return 7;
        
    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
        Gerente gerenteTemporario = vetGerente.get(indiceLinha);
        Usuario usuarioTemporario = vetUsuario.get(indiceLinha);

        return switch (indiceColuna) {
            
            case 0 -> usuarioTemporario.getCodigo();
            case 1 -> usuarioTemporario.getNome();
            case 2 -> usuarioTemporario.getIdade();
            case 3 -> usuarioTemporario.getSenha();
            case 4 -> usuarioTemporario.getEmail();
            case 5 -> usuarioTemporario.getTipoUsuario();
            case 6 -> gerenteTemporario.getCpf();
            default -> null;
                
        };
        
    }

    @Override
    public String getColumnName(int coluna) {
        
        return nomeColunnas[coluna];
        
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }
        
        return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente");
        
    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        
        return switch (indiceColuna) {
            
            case 0 -> Integer.class;
            case 2 -> Integer.class;
            default -> String.class;
                
        };
        
    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {
        
        Usuario usuarioModificar = this.vetUsuario.get(indiceLinha);
        Gerente gerenteModificar = this.vetGerente.get(indiceLinha);
        
        switch(indiceColuna){
            
            case 0:
                
                usuarioModificar.setCodigo((Integer)novoValor);
                gerenteModificar.setCodigo((Integer)novoValor); 
                break;
                
            case 1:
                
                usuarioModificar.setNome((String)novoValor);
                gerenteModificar.setNome((String)novoValor);
                break;
                
            case 2:
                
                usuarioModificar.setIdade((int)novoValor);
                gerenteModificar.setIdade((int)novoValor);
                break;
                
            case 3:
                
                usuarioModificar.setSenha((String)novoValor);
                gerenteModificar.setSenha((String)novoValor);
                break;
                
            case 4:
                
                usuarioModificar.setEmail((String)novoValor);
                gerenteModificar.setEmail((String)novoValor);
                break;
                
            case 5:
                
                usuarioModificar.setTipoUsuario((String)novoValor);
                gerenteModificar.setTipoUsuario((String)novoValor);
                break;
                
            case 6:
                
                gerenteModificar.setCpf((String)novoValor);
                break;
                
        }
        
        modificaUsuarioCliente(usuarioModificar, gerenteModificar);
        
    }
    
    public void removeLinha() {
        
        Gerente agendamentoDeleta = this.vetGerente.get(linha);
        
        if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente")){
            
            GerenteDAO.deletaGerente(agendamentoDeleta);
            this.vetGerente.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
            
        }else{
            
            JOptionPane.showMessageDialog(null, "Somente o gerente pode deletar gerentes!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
}
