package controller;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Servico;
import modelos.Usuario;
import repository.ServicoDAO;
import telas.Login;

public class RegraTabelaServico extends AbstractTableModel {
    
    private Vector<Servico> vetServico = ServicoDAO.consultaServico();
    private String nomeColunnas[] = {"Produtos", "Tipo Serviço", "Manutenção", "Modalidade"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaServico(Servico servico){
        
        if(servico.getTipoServico() != null && !servico.getTipoServico().equalsIgnoreCase("")){
            
            ServicoDAO.updateServico(servico);
            
        }
        
    }
    

    @Override
    public int getRowCount() {
        
        return this.vetServico.size();
        
    }

    @Override
    public int getColumnCount() {
        
        return 4;
        
    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
        Servico servicoTemporario = vetServico.get(indiceLinha);

        return switch (indiceColuna) {
            
            case 0 -> servicoTemporario.getProdutos();
            case 1 -> servicoTemporario.getTipoServico();
            case 2 -> servicoTemporario.getManutencao();
            case 3 -> servicoTemporario.getModalidade();
            default -> null;
                
        };
        
    }

    @Override
    public String getColumnName(int coluna) {
        
        return nomeColunnas[coluna];
        
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }
        
        return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente") && indiceColuna != 1;
        
    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        
        return switch (indiceColuna) {
            
            default -> String.class;
                
        };
        
    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {
        
        Servico servicoModificar = this.vetServico.get(indiceLinha);
        
        switch(indiceColuna){
            
            case 0:
                
                servicoModificar.setProdutos((String)novoValor);
                break;
                
            case 1:
                
                servicoModificar.setTipoServico((String)novoValor);
                break;
                
            case 2:
                
                servicoModificar.setManutencao((String)novoValor);
                break;
                
            case 3:
                
                servicoModificar.setModalidade((String)novoValor);
                break;
                
        }
        
        modificaServico(servicoModificar);
        
    }
    
    public void removeLinha() {
        
        Servico servicoDeleta = this.vetServico.get(linha);
        
        if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente")){
            
            ServicoDAO.deletaServico(servicoDeleta);
            this.vetServico.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
            
        }else{
            
            JOptionPane.showMessageDialog(null, "Somente o gerente pode deletar serviços!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
}
