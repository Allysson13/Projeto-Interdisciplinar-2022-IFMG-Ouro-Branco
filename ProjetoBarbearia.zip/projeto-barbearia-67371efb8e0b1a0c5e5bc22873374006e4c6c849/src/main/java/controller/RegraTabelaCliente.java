package controller;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Cliente;
import modelos.Usuario;
import repository.ClienteDAO;
import repository.UsuarioDAO;
import telas.Login;

public class RegraTabelaCliente extends AbstractTableModel {
    
    private Vector<Cliente> vetCliente = ClienteDAO.consultaCliente();
    private Vector<Usuario> vetUsuario = UsuarioDAO.consultaUsuarioCliente();
    //private String nomeColunnas[] = {"Código", "Nome", "Idade", "Senha", "Email", "Tipo Usuário", "Alergias", "Música favorita"};
    private String nomeColunnas[] = {"Código", "Nome", "Idade", "Email", "Tipo Usuário", "Alergias", "Música favorita"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaUsuarioCliente(Usuario usuario, Cliente cliente){
        
        if(usuario != null && usuario.getCodigo() != 0){
            
            UsuarioDAO.updateUsuario(usuario);
            ClienteDAO.updateCliente(cliente);
            /*FramePrincipal framePai = new FramePrincipal();
            framePai.trocarPainel(null);*/
            
        }
        
    }
    
    @Override
    public int getRowCount() {
        
        return this.vetCliente.size();
        
    }

    @Override
    public int getColumnCount() {
        
        return 7;
        
    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
        Cliente clienteTemporario = vetCliente.get(indiceLinha);
        Usuario usuarioTemporario = vetUsuario.get(indiceLinha);

        switch (indiceColuna) {

            case 0:
                
                return usuarioTemporario.getCodigo();
                
            case 1:
                
                return usuarioTemporario.getNome();
                
            case 2:
                
                return usuarioTemporario.getIdade();
                
            /*case 3:
                
                return usuarioTemporario.getSenha();*/
                
            case 3:
                
                return usuarioTemporario.getEmail();
                
            case 4:
                
                return usuarioTemporario.getTipoUsuario();
                
            case 5:
                
                return clienteTemporario.getAlergias();
                
            case 6:
                
                return clienteTemporario.getMusicaFavorita();
                
            default:
                
                return null;

        }
        
    }

    @Override
    public String getColumnName(int coluna) {
        
        return nomeColunnas[coluna];
        
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }
        
        return this.usuarioLogado.getCodigo() == indiceLinha + 1 && indiceColuna != 0;
        
    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        
        return switch (indiceColuna) {
            
            case 0 -> Integer.class;
            case 2 -> Integer.class;
            default -> String.class;
                
        };
        
    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {
        
        Usuario usuarioModificar = this.vetUsuario.get(indiceLinha);
        Cliente clienteModificar = this.vetCliente.get(indiceLinha);
        
        switch(indiceColuna){
            
            case 0:
                
                usuarioModificar.setCodigo((Integer)novoValor);
                clienteModificar.setCodigo((Integer)novoValor); 
                break;
                
            case 1:
                
                usuarioModificar.setNome((String)novoValor);
                clienteModificar.setNome((String)novoValor);
                break;
                
            case 2:
                
                usuarioModificar.setIdade((int)novoValor);
                clienteModificar.setIdade((int)novoValor);
                break;
                
            /*case 3:
                
                usuarioModificar.setSenha((String)novoValor);
                clienteModificar.setSenha((String)novoValor);
                break;*/
                
            case 3:
                
                usuarioModificar.setEmail((String)novoValor);
                clienteModificar.setEmail((String)novoValor);
                break;
                
            case 4:
                
                usuarioModificar.setTipoUsuario((String)novoValor);
                clienteModificar.setTipoUsuario((String)novoValor);
                break;
                
            case 5:
                
                clienteModificar.setAlergias((String)novoValor);
                break;
                
            case 6:
                
                clienteModificar.setMusicaFavorita((String)novoValor);
                break;
                
        }
        
        modificaUsuarioCliente(usuarioModificar, clienteModificar);
        
    }
    
    public void removeLinha() {

        Cliente clienteDeleta = this.vetCliente.get(linha);
        
        if(usuarioLogado.getCodigo() == linha){
        
            ClienteDAO.deletaCliente(clienteDeleta);
            this.vetCliente.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
        
        }else{
            
            JOptionPane.showMessageDialog(null, "Você não pode apagar outros clientes!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
            
        }
        
    }

}
