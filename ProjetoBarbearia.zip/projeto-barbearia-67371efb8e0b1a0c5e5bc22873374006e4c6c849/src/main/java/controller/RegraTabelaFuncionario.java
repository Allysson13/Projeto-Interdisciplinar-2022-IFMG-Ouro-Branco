package controller;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Funcionario;
import modelos.Usuario;
import repository.FuncionarioDAO;
import repository.UsuarioDAO;
import telas.Login;

public class RegraTabelaFuncionario extends AbstractTableModel {
    
    private Vector<Funcionario> vetFuncionario = FuncionarioDAO.consultaFuncionario();
    private Vector<Usuario> vetUsuario = UsuarioDAO.consultaUsuarioFuncionario();
    //private String nomeColunnas[] = {"Código", "Nome", "Idade", "Senha", "Email", "Tipo Usuário", "Salário", "Carga Horária"};
    private String nomeColunnas[] = {"Código", "Nome", "Idade", "Email", "Tipo Usuário", "Salário", "Carga Horária"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;

    public void modificaUsuarioCliente(Usuario usuario, Funcionario funcionario){
        
        if(usuario != null && usuario.getCodigo() != 0){
            
            UsuarioDAO.updateUsuario(usuario);
            FuncionarioDAO.updateFuncionario(funcionario);
            /*FramePrincipal framePai = new FramePrincipal();
            framePai.trocarPainel(null);*/
            
        }
        
    }
    
    @Override
    public int getRowCount() {
        
        return this.vetFuncionario.size();
        
    }

    @Override
    public int getColumnCount() {
        
        return 7;
        
    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
        Funcionario funcionarioTemporario = vetFuncionario.get(indiceLinha);
        Usuario usuarioTemporario = vetUsuario.get(indiceLinha);

        switch (indiceColuna) {

            case 0:
                
                return usuarioTemporario.getCodigo();
                
            case 1:
                
                return usuarioTemporario.getNome();
                
            case 2:
                
                return usuarioTemporario.getIdade();
                
            /*case 3:
                
                return usuarioTemporario.getSenha();*/
                
            case 3:
                
                return usuarioTemporario.getEmail();
                
            case 4:
                
                return usuarioTemporario.getTipoUsuario();
                
            case 5:
                
                usuarioLogado = Login.retornaUsuarioLogado();
                String tipo = usuarioLogado.getTipoUsuario();
        
                if(usuarioLogado == null){
            
                    JOptionPane.showMessageDialog(null, "Faça login para acessar essa tabela!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
                }
                
                //if((tipo.equalsIgnoreCase("funcionario") || tipo.equalsIgnoreCase("gerente")) && usuarioTemporario.getCodigo() == indiceColuna){
                if(tipo.equalsIgnoreCase("funcionario") || tipo.equalsIgnoreCase("gerente")){
                    
                    return funcionarioTemporario.getSalario();
                    
                }else{
                    
                    return 0;
                    
                }
                
            case 6:
                
                usuarioLogado = Login.retornaUsuarioLogado();
                tipo = usuarioLogado.getTipoUsuario();
        
                if(usuarioLogado == null){
            
                    JOptionPane.showMessageDialog(null, "Faça login para acessar essa tabela!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
                }
                
                //if((tipo.equalsIgnoreCase("funcionario") || tipo.equalsIgnoreCase("gerente")) && usuarioTemporario.getCodigo() == indiceColuna){
                if(tipo.equalsIgnoreCase("funcionario") || tipo.equalsIgnoreCase("gerente")){
                    
                    return funcionarioTemporario.getCargaHoraria();
                    
                }else{
                    
                    return 0;
                    
                }
                
            default:
                
                return null;

        }
        
    }

    @Override
    public String getColumnName(int coluna) {
        
        return nomeColunnas[coluna];
        
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }
        
        //return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente");
        
        if(indiceColuna > 4){
            
            return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente");
            
        }else{
            
            return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("funcionario") || this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente");
            
        }
        
    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        
        return switch (indiceColuna) {
            
            case 0 -> Integer.class;
            case 2 -> Integer.class;
            case 5 -> Double.class;
            case 6 -> Double.class;
            default -> String.class;
                
        };
        
    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {
        
        Usuario usuarioModificar = this.vetUsuario.get(indiceLinha);
        Funcionario funcionarioModificar = this.vetFuncionario.get(indiceLinha);
        
        switch(indiceColuna){
            
            case 0:
                
                usuarioModificar.setCodigo((Integer)novoValor);
                funcionarioModificar.setCodigo((Integer)novoValor); 
                break;
                
            case 1:
                
                usuarioModificar.setNome((String)novoValor);
                funcionarioModificar.setNome((String)novoValor);
                break;
                
            case 2:
                
                usuarioModificar.setIdade((int)novoValor);
                funcionarioModificar.setIdade((int)novoValor);
                break;
                
            /*case 3:
                
                usuarioModificar.setSenha((String)novoValor);
                funcionarioModificar.setSenha((String)novoValor);
                break;*/
                
            case 3:
                
                usuarioModificar.setEmail((String)novoValor);
                funcionarioModificar.setEmail((String)novoValor);
                break;
                
            case 4:
                
                usuarioModificar.setTipoUsuario((String)novoValor);
                funcionarioModificar.setTipoUsuario((String)novoValor);
                break;
                
            case 5:
                
                funcionarioModificar.setSalario((Double)novoValor);
                break;
                
            case 6:
                
                funcionarioModificar.setCargaHoraria((Double)novoValor);
                break;
                
        }
        
        modificaUsuarioCliente(usuarioModificar, funcionarioModificar);
        
    }
    
    public void removeLinha() {
        
        Funcionario funcionarioDeleta = this.vetFuncionario.get(linha);
        
        if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente")){
            
            FuncionarioDAO.deletaFuncionario(funcionarioDeleta);
            this.vetFuncionario.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
            
        }else{
            
            JOptionPane.showMessageDialog(null, "Somente o gerente pode deletar funcionários!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
            
        }    
        
    }
    
}
