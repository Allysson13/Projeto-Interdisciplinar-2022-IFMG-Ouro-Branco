package controller;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Usuario;
import repository.UsuarioDAO;
import telas.Login;

public class RegraTabelaUsuario extends AbstractTableModel {

    private Vector<Usuario> vetUsuario = UsuarioDAO.consultaUsuario();
    private String nomeColunnas[] = {"Email"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaUsuario(Usuario usuario){
        
        //sera que o usuario foi instanciado e sera que ele ESTÁ no BD
        if(usuario != null && usuario.getCodigo() != 0){
            
            UsuarioDAO.updateUsuario(usuario);
            
        }
        
    }
    
    //quantidade de linhas desenhadas na tabela
    @Override
    public int getRowCount() {

        return this.vetUsuario.size();

    }

    //quantidade de colunas desenhadas na tabela
    @Override
    public int getColumnCount() {

        return 1;

    }

    //qual o valor de CADA célula da tabela
    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {

        Usuario usuarioTemporario = vetUsuario.get(indiceLinha);

        return switch (indiceColuna) {
            
            case 0 -> usuarioTemporario.getEmail();
            default -> null;
                
        };

    }

    //nome de cada coluna da tabela (Cabeçalho)
    @Override
    public String getColumnName(int coluna) {

        return nomeColunnas[coluna];

    }

    //Definindo quais células podem ser modificadas (editadas)
    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }

        return this.usuarioLogado.getCodigo() == indiceLinha + 1;

    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {

        return switch (indiceColuna) {
            
            case 0 -> Integer.class;
            default -> String.class;
                
        };

    }

    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {
        
        Usuario usuarioModificar = this.vetUsuario.get(indiceLinha);
        
        switch(indiceColuna){
            
            case 0: //modificar o código
                
                usuarioModificar.setCodigo((Integer)novoValor); break;
                
            case 1: //modificar o nome
                
                usuarioModificar.setNome((String)novoValor); break;
                
            case 2: //modificar a idade
                
                usuarioModificar.setIdade((int)novoValor);break;
                
            case 3: //modificar a senha
                
                usuarioModificar.setSenha((String)novoValor);break;
                
            case 4: //modificar o email
                
                usuarioModificar.setEmail((String)novoValor);
                
            case 5: //modificar o tipoUsuario
                
                usuarioModificar.setTipoUsuario((String)novoValor);
                
        }
        
        //invoco a atualização do objeto na base de dados
        modificaUsuario(usuarioModificar);
        
    }
    
    public void removeLinha() {
        
        Usuario usuarioDeleta = this.vetUsuario.get(linha);
        UsuarioDAO.deletaUsuario(usuarioDeleta);
        this.vetUsuario.remove(linha);
        this.fireTableRowsDeleted(linha, linha);
       
    }

}
