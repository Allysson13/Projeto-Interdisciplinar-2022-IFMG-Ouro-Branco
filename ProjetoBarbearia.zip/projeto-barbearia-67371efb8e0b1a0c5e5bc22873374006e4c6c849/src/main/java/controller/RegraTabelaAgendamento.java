package controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Usuario;
import repository.AgendamentoDAO;
import telas.Login;
import modelos.Agendamento;

public class RegraTabelaAgendamento extends AbstractTableModel {
    
    private Vector<Agendamento> vetAgendamento = AgendamentoDAO.consultaAgendamento();
    private String nomeColunnas[] = {"Data", "Serviço", "Valor", "Nome do Cliente"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaAgendamento(Agendamento agendamento){
        
        if(agendamento != null && !agendamento.getTipoServico().equalsIgnoreCase("")){
            
            AgendamentoDAO.updateAgendamento(agendamento);
            
        }
        
    }

    @Override
    public int getRowCount() {
        
        return this.vetAgendamento.size();
        
    }

    @Override
    public int getColumnCount() {
        
        return 4;
        
    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
        Agendamento agendamentoTemporario = vetAgendamento.get(indiceLinha);
        
        SimpleDateFormat formatoData = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        //JOptionPane.showMessageDialog(null, new Timestamp(agendamentoTemporario.getData().getTime()));

        return switch (indiceColuna) {
            //(Date) formatoData.parse(fieldData.getText() + " " + fieldHorario.getText());
            //case 0 -> formatoData.parse(formatoData.format(agendamentoTemporario.getData())); 
            //case 0 -> new Timestamp(agendamentoTemporario.getData().getTime());
            case 0 -> agendamentoTemporario.getData();
            case 1 -> agendamentoTemporario.getTipoServico();
            case 2 -> agendamentoTemporario.getValor();
            case 3 -> agendamentoTemporario.getNomeCliente();
            default -> null;
                
        };
        
    }

    @Override
    public String getColumnName(int coluna) {
        
        return nomeColunnas[coluna];
        
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }
        
        return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente") || this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("funcionario");
        
    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        
        return switch (indiceColuna) {
            
            case 0 -> Timestamp.class;
            case 2 -> Double.class;
            case 4 -> Date.class;
            default -> String.class;
                
        };
        
    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {
        
        Agendamento agendamentoModificar = this.vetAgendamento.get(indiceLinha);
        
        switch(indiceColuna){
            
            case 0:
                
                agendamentoModificar.setData((Timestamp)novoValor);
                break;
                
            case 1:
                
                agendamentoModificar.setTipoServico((String)novoValor);
                break;
                
            case 2:
                
                agendamentoModificar.setValor((Double)novoValor);
                break;
                
            case 3:
                
                agendamentoModificar.setNomeCliente((String)novoValor);
                break;
                
        }
        
        modificaAgendamento(agendamentoModificar);
        
    }
    
    public void removeLinha() {
        
        Agendamento agendamentoDeleta = this.vetAgendamento.get(linha);
        
        if(agendamentoDeleta.getNomeCliente().equalsIgnoreCase(agendamentoDeleta.getNomeCliente())){
        
            AgendamentoDAO.deletaAgendamento(agendamentoDeleta);
            this.vetAgendamento.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
        
        }else{
            
            JOptionPane.showMessageDialog(null, "Somente o usuario que fez o agendamento pode apaga-lo!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
            
        }
       
    }
    
}