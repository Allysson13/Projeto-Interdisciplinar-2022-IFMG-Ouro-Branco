package controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Evento;
import modelos.Usuario;
import repository.EventoDAO;
import telas.Login;

public class RegraTabelaEvento extends AbstractTableModel {
    
    private Vector<Evento> vetEvento = EventoDAO.consultaEvento();
    private String nomeColunnas[] = {"Nome Convidados", "Telefone Fotógrafo", "Duração", "Data", "Cenário", "Alimentação"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaEvento(Evento evento) {

        if (evento.getData() != null) {

            EventoDAO.updateEvento(evento);

        }

    }

    @Override
    public int getRowCount() {
        
        return this.vetEvento.size();
        
    }

    @Override
    public int getColumnCount() {
        
        return 6;
        
    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
        Evento eventoTemporario = vetEvento.get(indiceLinha);

        return switch (indiceColuna) {
            
            case 0 -> eventoTemporario.getNomeConvidados();
            case 1 -> eventoTemporario.getFotografo();
            case 2 -> eventoTemporario.getDuracao();
            case 3 -> eventoTemporario.getData();
            case 4 -> eventoTemporario.getCenario();
            case 5 -> eventoTemporario.getAlimentacao();
            default -> null;
                
        };
        
    }

    @Override
    public String getColumnName(int coluna) {
        
        return nomeColunnas[coluna];
        
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }
        
        return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente");
        
    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        
        return switch (indiceColuna) {
            
            case 2 -> Double.class;
            case 3 -> Date.class;
            default -> String.class;
                
        };
        
    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {

        Evento eventoModificar = this.vetEvento.get(indiceLinha);

        switch (indiceColuna) {

            case 0:

                eventoModificar.setNomeConvidados((String) novoValor);
                break;

            case 1:

                eventoModificar.setFotografo((String) novoValor);
                break;

            case 2:

                eventoModificar.setDuracao((Double) novoValor);
                break;

            case 3:

                eventoModificar.setData((Timestamp) novoValor);
                break;

            case 4:
                eventoModificar.setCenario((String) novoValor);
                break;

            case 5:
                eventoModificar.setAlimentacao((String) novoValor);
                break;

        }

        modificaEvento(eventoModificar);

    }
    
    public void removeLinha() {
        
        Evento eventoDeleta = this.vetEvento.get(linha);
        
        if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente")){
        
            EventoDAO.deletaEvento(eventoDeleta);
            this.vetEvento.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
        
        }else{
            
            JOptionPane.showMessageDialog(null, "Somente o gerente pode deletar eventos!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
}