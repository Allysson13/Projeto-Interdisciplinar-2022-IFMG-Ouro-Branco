package controller;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.ContaBancaria;
import modelos.Usuario;
import repository.ContaBancariaDAO;
import telas.Login;

public class RegraTabelaContaBancaria extends AbstractTableModel {
    
    private Vector<ContaBancaria> vetContaBancaria = ContaBancariaDAO.consultaContaBancaria();
    private String nomeColunnas[] = {"Código", "Agência", "Nome do Titular"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaContaBancaria(ContaBancaria contaBancaria){
        
        if(contaBancaria.getCodigo()!= null && !contaBancaria.getCodigo().equalsIgnoreCase("")){
            
            ContaBancariaDAO.updateServico(contaBancaria);
            
        }
        
    }

    @Override
    public int getRowCount() {
        
        return this.vetContaBancaria.size();
        
    }

    @Override
    public int getColumnCount() {
        
        return 3;
        
    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
    ContaBancaria contaBancariaTemporario = vetContaBancaria.get(indiceLinha);

        return switch (indiceColuna) {
            
            case 0 -> contaBancariaTemporario.getCodigo();
            case 1 -> contaBancariaTemporario.getAgencia();
            case 2 -> contaBancariaTemporario.getNomeTitular();
            default -> null;
                
        };
        
    }

    @Override
    public String getColumnName(int coluna) {
        
        return nomeColunnas[coluna];
        
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }
        
        return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente");
        
    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        
        return switch (indiceColuna) {
            
            default -> String.class;
                
        };
        
    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {
        
        ContaBancaria contaBancariaModificar = this.vetContaBancaria.get(indiceLinha);
        
        switch(indiceColuna){
            
            case 0:
                
                contaBancariaModificar.setCodigo((String)novoValor);
                break;
                
            case 1:
                
                contaBancariaModificar.setAgencia((String)novoValor);
                break;
                
            case 2:
                
                contaBancariaModificar.setNomeTitular((String)novoValor);
                break;
                
        }
        
        modificaContaBancaria(contaBancariaModificar);
        
    }
    
    public void removeLinha() {

        ContaBancaria cBancariaDeleta = this.vetContaBancaria.get(linha);
        
        if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente")){
        
            ContaBancariaDAO.deletaContaBancaria(cBancariaDeleta);
            this.vetContaBancaria.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
        
        }else{
        
            JOptionPane.showMessageDialog(null, "Somente o gerente pode deletar as contas bancarias!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
        
        }
        
    }
    
}