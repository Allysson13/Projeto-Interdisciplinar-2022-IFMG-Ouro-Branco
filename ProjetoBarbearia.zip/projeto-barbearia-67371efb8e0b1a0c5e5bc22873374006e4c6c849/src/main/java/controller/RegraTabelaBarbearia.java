package controller;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Barbearia;
import modelos.Usuario;
import repository.BarbeariaDAO;
import telas.Login;

public class RegraTabelaBarbearia extends AbstractTableModel {

    private Vector<Barbearia> vetBarbearia = BarbeariaDAO.consultaBarbearia();
    private String nomeColunnas[] = {"ID", "Nome Gerente"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaBarbearia(Barbearia barbearia) {

        if (barbearia.getId() != null && !barbearia.getId().equalsIgnoreCase("")) {

            BarbeariaDAO.updateBarbearia(barbearia);

        }

    }

    @Override
    public int getRowCount() {

        return this.vetBarbearia.size();

    }

    @Override
    public int getColumnCount() {

        return 2;

    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {

        Barbearia barbeariaTemporario = vetBarbearia.get(indiceLinha);

        return switch (indiceColuna) {

            case 0 -> barbeariaTemporario.getId();
            case 1 -> barbeariaTemporario.getNomeGerente();
            default -> null;

        };

    }

    @Override
    public String getColumnName(int coluna) {

        return nomeColunnas[coluna];

    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }

        return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente");

    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {

        return switch (indiceColuna) {

            default -> String.class;

        };

    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {

        Barbearia barbeariaModificar = this.vetBarbearia.get(indiceLinha);

        switch (indiceColuna) {

            case 0:

                barbeariaModificar.setId((String) novoValor);
                break;

            case 1:

                barbeariaModificar.setNomeGerente((String) novoValor);
                break;
        }

        modificaBarbearia(barbeariaModificar);

    }
    
    public void removeLinha() {

        Barbearia barbeariaDeleta = this.vetBarbearia.get(linha);
        
        if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente")){
            
            BarbeariaDAO.deletaBarbearia(barbeariaDeleta);
            this.vetBarbearia.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
            
        }else{
        
            JOptionPane.showMessageDialog(null, "Somente o gerente pode deletar a barbearia!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
            
        }
    
    }

}
