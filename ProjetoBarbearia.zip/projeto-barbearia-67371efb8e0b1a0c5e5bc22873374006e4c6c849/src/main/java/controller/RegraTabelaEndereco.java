package controller;

import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Endereco;
import modelos.Usuario;
import repository.EnderecoDAO;
import telas.Login;

public class RegraTabelaEndereco extends AbstractTableModel {
    
    private Vector<Endereco> vetEndereco = EnderecoDAO.consultaEndereco();
    private String nomeColunnas[] = {"Id", "CEP", "Bairro", "Número"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaEndereco(Endereco endereco) {

        EnderecoDAO.updateEndereco(endereco);

    }

    @Override
    public int getRowCount() {
        
        return this.vetEndereco.size();
        
    }

    @Override
    public int getColumnCount() {
        
        return 4;
        
    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
    Endereco enderecoTemporario = vetEndereco.get(indiceLinha);

        return switch (indiceColuna) {
            
            case 0 -> enderecoTemporario.getId();
            case 1 -> enderecoTemporario.getCep();
            case 2 -> enderecoTemporario.getBairro();
            case 3 -> enderecoTemporario.getNumero();
            default -> null;
                
        };
        
    }

    @Override
    public String getColumnName(int coluna) {
        
        return nomeColunnas[coluna];
        
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }
        
        return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente");
        
    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        
        return switch (indiceColuna) {
            
            default -> String.class;
                
        };
        
    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {

        Endereco enderecoModificar = this.vetEndereco.get(indiceLinha);

        switch (indiceColuna) {

            case 0:

                enderecoModificar.setId((Integer) novoValor);
                break;

            case 1:

                enderecoModificar.setCep((String) novoValor);
                break;

            case 2:

                enderecoModificar.setBairro((String) novoValor);
                break;

            case 3:

                enderecoModificar.setNumero((String) novoValor);
                break;

        }

        modificaEndereco(enderecoModificar);

    }
    
    public void removeLinha() {
        
        Endereco enderecoDeleta = this.vetEndereco.get(linha);
        
        if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente")){
        
            EnderecoDAO.deletaEndereco(enderecoDeleta);
            this.vetEndereco.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
        
        }
        
        JOptionPane.showMessageDialog(null, "Somente o gerente pode deletar o endereço!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
        
    }
    
}