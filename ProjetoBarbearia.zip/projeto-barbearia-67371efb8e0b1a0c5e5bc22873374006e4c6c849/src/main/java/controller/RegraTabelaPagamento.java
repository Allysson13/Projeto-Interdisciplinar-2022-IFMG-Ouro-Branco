package controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import modelos.Pagamento;
import modelos.Usuario;
import repository.PagamentoDAO;
import telas.Login;

public class RegraTabelaPagamento extends AbstractTableModel {
    
    private Vector<Pagamento> vetPagamento = PagamentoDAO.consultaPagamento();
    private String nomeColunnas[] = {"Data", "Nome", "Estado", "Valor", "Forma de Pagamento"};
    private static Usuario usuarioLogado = Login.retornaUsuarioLogado();
    private int linha;
    
    public void modificaPagamento(Pagamento pagamento){
        
        if(pagamento.getData() != null){
            
            PagamentoDAO.updatePagamento(pagamento);
            
        }
        
    }

    @Override
    public int getRowCount() {
        
        return this.vetPagamento.size();
        
    }

    @Override
    public int getColumnCount() {
        
        return 5;
        
    }

    @Override
    public Object getValueAt(int indiceLinha, int indiceColuna) {
        
        Pagamento pagamentoTemporario = vetPagamento.get(indiceLinha);

        return switch (indiceColuna) {
            
            case 0 -> pagamentoTemporario.getData();
            case 1 -> pagamentoTemporario.getNomeCliente();
            case 2 -> pagamentoTemporario.isEstado();
            case 3 -> pagamentoTemporario.getValor();
            case 4 -> pagamentoTemporario.getFormaPag();
            default -> null;
                
        };
        
    }

    @Override
    public String getColumnName(int coluna) {
        
        return nomeColunnas[coluna];
        
    }

    @Override
    public boolean isCellEditable(int indiceLinha, int indiceColuna) {
        
        usuarioLogado = Login.retornaUsuarioLogado();
        
        this.linha = indiceLinha;
        
        if(usuarioLogado == null){
            
            JOptionPane.showMessageDialog(null, "Faça login para alterar as tabelas!!!", "Faça login!!!", JOptionPane.ERROR_MESSAGE);
            
        }
        
        return this.usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente");
        
    }

    @Override
    public Class<?> getColumnClass(int indiceColuna) {
        
        return switch (indiceColuna) {
            
            case 0 -> Date.class;
            case 2 -> Boolean.class;
            case 3 -> Double.class;
            default -> String.class;
                
        };
        
    }
    
    @Override
    public void setValueAt(Object novoValor, int indiceLinha, int indiceColuna) {
        
        Pagamento pagamentoModificar = this.vetPagamento.get(indiceLinha);
        
        switch(indiceColuna){
            
            case 0:
                
                pagamentoModificar.setData((Timestamp)novoValor);
                break;
                
            case 1:
                
                pagamentoModificar.setNomeCliente((String)novoValor);
                break;
                
            case 2:
                
                pagamentoModificar.setEstado((boolean)novoValor);
                break;
                
            case 3:
                
                pagamentoModificar.setValor((Double)novoValor);
                break;
                
            case 4:
                
                pagamentoModificar.setFormaPag((String)novoValor);
                break;
                
        }
        
        modificaPagamento(pagamentoModificar);
        
    }
    
    public void removeLinha() {
        
        Pagamento agendamentoDeleta = this.vetPagamento.get(linha);
        
        if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente")){
            
            PagamentoDAO.deletaPagamento(agendamentoDeleta);
            this.vetPagamento.remove(linha);
            this.fireTableRowsDeleted(linha, linha);
            
        }else{
            
            JOptionPane.showMessageDialog(null, "Somente o gerente pode deletar pagamentos!!!", "Delete!", JOptionPane.ERROR_MESSAGE);
            
        }
        
    }
    
}