package telas;

import tabelas.TabelaServico;
import tabelas.TabelaFuncionario;
import tabelas.TabelaCliente;
import tabelas.TabelaUsuario;
import java.awt.BorderLayout;
import modelos.Usuario;
import tabelas.TabelaAgendamento;
import tabelas.TabelaBarbearia;
import tabelas.TabelaContaBancaria;
import tabelas.TabelaEndereco;
import tabelas.TabelaEvento;
import tabelas.TabelaGerente;
import tabelas.TabelaPagamento;

public class Tabelas extends javax.swing.JPanel {
    
    public static FramePrincipal framePai;

    public Tabelas(Usuario usuarioLogado, FramePrincipal pai) {
        
        initComponents();
        
        this.framePai = pai;
        
        setPanel();
        
        habilitarTabelas(usuarioLogado);
        
    }
    
    private void habilitarTabelas(Usuario usuarioLogado){
        
        if(usuarioLogado == null || usuarioLogado == null){
            
            this.framePai.inValidaLogin();
            this.framePai.setSize(940, 520);
            for(int i = 1; i <= 10; i++){
                
                tabelas.setEnabledAt(i, false);
                
            }
            
        }else if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("cliente")){
            
            this.framePai.validaLogin();
            
            for(int i = 1; i <= 10; i++){
                
                tabelas.setEnabledAt(i, true);
                
            }
            
            tabelas.setEnabledAt(7, false);
            tabelas.setEnabledAt(8, false);
            
        }else if(usuarioLogado.getTipoUsuario().equalsIgnoreCase("funcionario")){
            
            this.framePai.validaLogin();
            
            for(int i = 1; i <= 10; i++){
                
                tabelas.setEnabledAt(i, true);
                
            }
            
            tabelas.setEnabledAt(7, false);
            tabelas.setEnabledAt(8, false);
            
            
        }else{
            
            this.framePai.validaLogin();
            
            for(int i = 1; i <= 10; i++){
                
                tabelas.setEnabledAt(i, true);
                
            }
            
        }
        
    }
    
    private void setPanel(){
        
        usuarioPanel.setLayout(new BorderLayout());
        usuarioPanel.add(new TabelaUsuario());
        
        clientePanel.setLayout(new BorderLayout());
        clientePanel.add(new TabelaCliente());
        
        funcionarioPanel.setLayout(new BorderLayout());
        funcionarioPanel.add(new TabelaFuncionario());
        
        servicoPanel.setLayout(new BorderLayout());
        servicoPanel.add(new TabelaServico());
        
        pagamentoPanel.setLayout(new BorderLayout());
        pagamentoPanel.add(new TabelaPagamento());
        
        agendamentoPanel.setLayout(new BorderLayout());
        agendamentoPanel.add(new TabelaAgendamento());
        
        eventoPanel.setLayout(new BorderLayout());
        eventoPanel.add(new TabelaEvento());
        
        contaBancariaPanel.setLayout(new BorderLayout());
        contaBancariaPanel.add(new TabelaContaBancaria());
        
        gerentePanel.setLayout(new BorderLayout());
        gerentePanel.add(new TabelaGerente());
        
        enderecoPanel.setLayout(new BorderLayout());
        enderecoPanel.add(new TabelaEndereco());
        
        barbeariaPanel.setLayout(new BorderLayout());
        barbeariaPanel.add(new TabelaBarbearia());
            
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabelas = new javax.swing.JTabbedPane();
        usuarioPanel = new javax.swing.JPanel();
        clientePanel = new javax.swing.JTabbedPane();
        funcionarioPanel = new javax.swing.JTabbedPane();
        servicoPanel = new javax.swing.JTabbedPane();
        pagamentoPanel = new javax.swing.JTabbedPane();
        agendamentoPanel = new javax.swing.JTabbedPane();
        eventoPanel = new javax.swing.JTabbedPane();
        contaBancariaPanel = new javax.swing.JTabbedPane();
        gerentePanel = new javax.swing.JTabbedPane();
        enderecoPanel = new javax.swing.JTabbedPane();
        barbeariaPanel = new javax.swing.JTabbedPane();

        javax.swing.GroupLayout usuarioPanelLayout = new javax.swing.GroupLayout(usuarioPanel);
        usuarioPanel.setLayout(usuarioPanelLayout);
        usuarioPanelLayout.setHorizontalGroup(
            usuarioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        usuarioPanelLayout.setVerticalGroup(
            usuarioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 534, Short.MAX_VALUE)
        );

        tabelas.addTab("Usuario", usuarioPanel);
        tabelas.addTab("Cliente", clientePanel);
        tabelas.addTab("Funcionário", funcionarioPanel);
        tabelas.addTab("Serviço", servicoPanel);
        tabelas.addTab("Pagamento", pagamentoPanel);
        tabelas.addTab("Agendamento", agendamentoPanel);
        tabelas.addTab("Evento", eventoPanel);
        tabelas.addTab("Conta Bancária", contaBancariaPanel);
        tabelas.addTab("Gerente", gerentePanel);
        tabelas.addTab("Endereço", enderecoPanel);
        tabelas.addTab("Barbearia", barbeariaPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabelas)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabelas, javax.swing.GroupLayout.DEFAULT_SIZE, 567, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane agendamentoPanel;
    private javax.swing.JTabbedPane barbeariaPanel;
    private javax.swing.JTabbedPane clientePanel;
    private javax.swing.JTabbedPane contaBancariaPanel;
    private javax.swing.JTabbedPane enderecoPanel;
    private javax.swing.JTabbedPane eventoPanel;
    private javax.swing.JTabbedPane funcionarioPanel;
    private javax.swing.JTabbedPane gerentePanel;
    private javax.swing.JTabbedPane pagamentoPanel;
    private javax.swing.JTabbedPane servicoPanel;
    private javax.swing.JTabbedPane tabelas;
    private javax.swing.JPanel usuarioPanel;
    // End of variables declaration//GEN-END:variables
}
