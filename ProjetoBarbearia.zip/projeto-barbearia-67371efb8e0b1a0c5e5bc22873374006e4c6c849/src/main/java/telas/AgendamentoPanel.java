package telas;

import controller.RegraTabelaAgendamento;
import java.sql.Timestamp;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;
import javax.swing.JOptionPane;
import modelos.Agendamento;
import modelos.Pagamento;
import repository.AgendamentoDAO;
import repository.PagamentoDAO;

public class AgendamentoPanel extends javax.swing.JPanel {

    private FramePrincipal framePai;
    private String nome;
    private Timestamp data;
    private String tipoServico;
    private double valor;
    private RegraTabelaAgendamento minhasRegras;
    private Date agora;
    private String formaPag;

    public AgendamentoPanel(FramePrincipal pai) {

        initComponents();

        this.framePai = pai;
        this.minhasRegras = new RegraTabelaAgendamento();
        tabelaAgendamentos.setModel(minhasRegras);
        
        Calendar c = Calendar.getInstance();
        this.agora = c.getTime();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaAgendamentos = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        fieldNome = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        botaoFechar = new javax.swing.JButton();
        botaoConfirmar = new javax.swing.JButton();
        tipoServicoCombo = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        fieldData = new javax.swing.JFormattedTextField();
        fieldHorario = new javax.swing.JFormattedTextField();
        jLabel16 = new javax.swing.JLabel();
        fieldFormaPag = new javax.swing.JTextField();

        jPanel1.setBackground(new java.awt.Color(0, 51, 102));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 500));

        tabelaAgendamentos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabelaAgendamentos);

        jPanel4.setBackground(new java.awt.Color(0, 51, 153));

        jLabel11.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 255, 255));
        jLabel11.setText("Agendamento");

        jLabel12.setBackground(new java.awt.Color(0, 0, 204));
        jLabel12.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 255, 255));
        jLabel12.setText("Informe o seu nome: ");

        fieldNome.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        fieldNome.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldNomeFocusLost(evt);
            }
        });
        fieldNome.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldNomeKeyReleased(evt);
            }
        });

        jLabel13.setBackground(new java.awt.Color(0, 0, 204));
        jLabel13.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 255, 255));
        jLabel13.setText("Informe a data do atendimento: ");

        jLabel14.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 255, 255));
        jLabel14.setText("Informe o tipo do serviço: ");

        botaoFechar.setBackground(new java.awt.Color(0, 0, 204));
        botaoFechar.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        botaoFechar.setForeground(new java.awt.Color(0, 255, 255));
        botaoFechar.setText("Fechar");
        botaoFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoFecharActionPerformed(evt);
            }
        });
        botaoFechar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botaoFecharKeyReleased(evt);
            }
        });

        botaoConfirmar.setBackground(new java.awt.Color(0, 0, 204));
        botaoConfirmar.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        botaoConfirmar.setForeground(new java.awt.Color(0, 255, 255));
        botaoConfirmar.setText("Confirmar");
        botaoConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoConfirmarActionPerformed(evt);
            }
        });
        botaoConfirmar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botaoConfirmarKeyReleased(evt);
            }
        });

        tipoServicoCombo.setBackground(new java.awt.Color(0, 0, 0));
        tipoServicoCombo.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        tipoServicoCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cabelo", "Barba", "Sobrancelha", "Cabelo&Barba", "Barba&Sobrancelha", "Cabelo&Sobrancelha", "Cabelo&Barba&Sobrancelha" }));
        tipoServicoCombo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tipoServicoComboKeyReleased(evt);
            }
        });

        jLabel15.setBackground(new java.awt.Color(0, 0, 204));
        jLabel15.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 255, 255));
        jLabel15.setText("Informe o horário do atendimento: ");

        try {
            fieldData.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        fieldData.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldDataFocusLost(evt);
            }
        });
        fieldData.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldDataKeyReleased(evt);
            }
        });

        try {
            fieldHorario.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        fieldHorario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldHorarioFocusLost(evt);
            }
        });
        fieldHorario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldHorarioKeyReleased(evt);
            }
        });

        jLabel16.setBackground(new java.awt.Color(0, 0, 204));
        jLabel16.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 255, 255));
        jLabel16.setText("Informe a forma de pagamento: ");

        fieldFormaPag.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        fieldFormaPag.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldFormaPagFocusLost(evt);
            }
        });
        fieldFormaPag.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldFormaPagKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tipoServicoCombo, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(92, 92, 92)
                                .addComponent(jLabel11))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(botaoConfirmar)
                                .addGap(94, 94, 94)
                                .addComponent(botaoFechar))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel14))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(fieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel13)
                                    .addComponent(jLabel15)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel12))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(fieldHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(fieldData, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 10, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(fieldFormaPag, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addComponent(fieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(fieldData, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(fieldHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(tipoServicoCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel16)
                .addGap(18, 18, 18)
                .addComponent(fieldFormaPag, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botaoFechar)
                    .addComponent(botaoConfirmar))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 572, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 560, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void fieldHorarioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldHorarioKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldHorarioKeyReleased

    private void fieldDataKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldDataKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldDataKeyReleased

    private void tipoServicoComboKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tipoServicoComboKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_tipoServicoComboKeyReleased

    private void botaoConfirmarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botaoConfirmarKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_botaoConfirmarKeyReleased

    private void botaoConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoConfirmarActionPerformed
        
        this.nome = fieldNome.getText();
        this.formaPag = fieldFormaPag.getText();
        
        SimpleDateFormat formatoData = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        try {

            Date data = (Date) formatoData.parse(fieldData.getText() + " " + fieldHorario.getText());
            this.data = new Timestamp(data.getTime());
            //JOptionPane.showMessageDialog(this, this.data);
            
            Vector<Agendamento> consultaAgendamento = AgendamentoDAO.consultaAgendamento();
            
            for(Agendamento a : consultaAgendamento){
                
                if(a.getData() == new Date(agora.getTime())){
                    
                    JOptionPane.showMessageDialog(this, "A data escolhida já está ocupada!!!", "Entrada da Data/Horario", JOptionPane.ERROR_MESSAGE);
                    return;
                    
                }
                
            }
            
            if(this.data.before(this.agora)){
                
                JOptionPane.showMessageDialog(this, "Informe um horário para o futuro!!!", "Entrada da Data", JOptionPane.ERROR_MESSAGE);
                return;
                
            }

        } catch (ParseException ex) {

            JOptionPane.showMessageDialog(this, "Erro na conversÃ£o para Data!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
        this.tipoServico = (String) tipoServicoCombo.getSelectedItem();
        
        String servicos = (String) tipoServicoCombo.getSelectedItem();
        
        String[] servico = servicos.split("&");
        
        if(servico.length == 3){
            
            this.valor = 35;
            
        }else if(servico.length == 2){
            
            if(servico[0].equalsIgnoreCase("Cabelo") && servico[1].equalsIgnoreCase("Barba")){
                
                this.valor = 30;
                
            }else if (servico[0].equalsIgnoreCase("Cabelo") && servico[1].equalsIgnoreCase("Sobrancelha")){
                
                this.valor = 25;
                
            }else{
                
                this.valor = 15;
                
            }
            
        }else{
            
            if(servico[0].equalsIgnoreCase("Cabelo")){
                
                this.valor = 20;
                
            }else if(servico[0].equalsIgnoreCase("Barba")){
                
                this.valor = 10;
                
            }else{
                
                this.valor = 5;
                
            }
            
        }

        Agendamento novoAtendimento = new Agendamento(this.data, this.tipoServico, this.valor, this.nome);
        Pagamento novoPagamento = new Pagamento(this.data, nome, false, valor, formaPag);
        
        AgendamentoDAO.inserirAtendimento(novoAtendimento);
        PagamentoDAO.inserirPagamento(novoPagamento);

        botaoFechar.doClick();
        
    }//GEN-LAST:event_botaoConfirmarActionPerformed

    private void botaoFecharKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botaoFecharKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_botaoFecharKeyReleased

    private void botaoFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoFecharActionPerformed
        
        this.framePai.trocarPainel(null);
        this.framePai.setSize(940, 672);
        
    }//GEN-LAST:event_botaoFecharActionPerformed

    private void fieldNomeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldNomeKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldNomeKeyReleased

    private void fieldNomeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldNomeFocusLost
        
        this.nome = fieldNome.getText();

        if (nome.equals("") || nome == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de nome!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }

    }//GEN-LAST:event_fieldNomeFocusLost

    private void fieldDataFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldDataFocusLost
        
        if (fieldData.getText().equals("") || fieldData.getText() == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de data!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }

    }//GEN-LAST:event_fieldDataFocusLost

    private void fieldHorarioFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldHorarioFocusLost
        
        if (fieldHorario.getText().equals("") || fieldHorario.getText() == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de horario!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldHorarioFocusLost

    private void fieldFormaPagFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldFormaPagFocusLost
        
        if (fieldFormaPag.getText().equals("") || fieldFormaPag.getText() == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de forma de pagamento!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldFormaPagFocusLost

    private void fieldFormaPagKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldFormaPagKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldFormaPagKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoConfirmar;
    private javax.swing.JButton botaoFechar;
    private javax.swing.JFormattedTextField fieldData;
    private javax.swing.JTextField fieldFormaPag;
    private javax.swing.JFormattedTextField fieldHorario;
    private javax.swing.JTextField fieldNome;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaAgendamentos;
    private javax.swing.JComboBox<String> tipoServicoCombo;
    // End of variables declaration//GEN-END:variables
}
