package telas;

import modelos.Cliente;
import modelos.Usuario;
import repository.UsuarioDAO;
import controller.RegraTabelaPerfil;
import java.util.Vector;
import javax.swing.JOptionPane;
import modelos.Funcionario;
import modelos.Gerente;
import repository.ClienteDAO;
import repository.FuncionarioDAO;
import repository.GerenteDAO;

public class CriarPerfil extends javax.swing.JPanel {

    private FramePrincipal framePai;
    private String nome;
    private int idade;
    private String tipoUsuario;
    private int usuario;
    private RegraTabelaPerfil minhasRegras;
    private String alergiasSalarioCpf;
    private String musicaCarga;
    private Usuario usuarioLogado;

    public CriarPerfil(FramePrincipal pai, int usuario) {

        initComponents();

        this.framePai = pai;
        this.usuario = usuario;

        this.minhasRegras = new RegraTabelaPerfil();
        tabelaPerfis.setModel(this.minhasRegras);
        musicaCargaHTxt.setVisible(false);
        this.usuarioLogado = Login.retornaUsuarioLogado();
        this.framePai.validaLogin();
        this.idade = 0;

        switch (usuario) {

            case 0:

                this.tipoUsuario = "cliente";

                this.musicaCargaHTxt.setVisible(true);
                this.labelVariavel1.setText("Informe as suas alergias: ");
                this.labelVariavel2.setText("Informe a sua música favorita: ");

                break;

            case 1:

                this.tipoUsuario = "funcionario";

                this.musicaCargaHTxt.setVisible(true);
                this.labelVariavel1.setText("Informe o seu salario: ");
                this.labelVariavel2.setText("Informe a sua carga horária: ");

                break;

            default:

                this.tipoUsuario = "gerente";

                this.labelVariavel1.setText("Informe o seu CPF: ");
                this.labelVariavel2.setVisible(false);
                this.musicaCargaHTxt.setVisible(false);

                break;

        }

    }

    private boolean verificaCPF(String cpf) {
        
        int soma1 = 0, soma2 = 0, num10, num11;
        
        Vector<Integer> vetCpf = new Vector<>();
        
        for(int i = 0; i < cpf.length(); i++){
            
            vetCpf.add(Integer.parseInt(cpf.charAt(i) + ""));
            
        }
        
        int indice = 8;
        
        for(int i = 2; i <= 10; i++){
            
            soma1 += vetCpf.get(indice) * i;
            
            indice--;
            
        }
        
        if(soma1 % 11 < 2){
            
            num10 = 0;
            
        }else{
            
            num10 = 11 - soma1 % 11;
            
        }
        
        indice = 9;
        
        for(int i = 2; i <= 11; i++){
            
            if(indice == 9){
                
               soma2 += num10 * i;
               
               indice--;
                
            }else{
            
                soma2 += vetCpf.get(indice) * i;
            
                indice--;
            
            }
        }
        
        if(soma2 % 11 < 2){
            
            num11 = 0;
            
        }else{
            
            num11 = 11 - soma2 % 11;
            
        }
        
        if(num10 == vetCpf.get(9) && num11 == vetCpf.get(10)){
            
            return true;
            
        }else{
            
            return false;
            
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        nomeTxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        idadeTxt = new javax.swing.JTextField();
        botaoConfirmar = new javax.swing.JButton();
        botaoFechar = new javax.swing.JButton();
        labelVariavel1 = new javax.swing.JLabel();
        alergiaSalarioCpfTxt = new javax.swing.JTextField();
        musicaCargaHTxt = new javax.swing.JTextField();
        labelVariavel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaPerfis = new javax.swing.JTable();

        setBackground(new java.awt.Color(0, 51, 102));
        setPreferredSize(new java.awt.Dimension(900, 500));

        jLabel1.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 255));
        jLabel1.setText("Crie Seu Perfil");

        jPanel3.setBackground(new java.awt.Color(0, 51, 153));

        jLabel2.setBackground(new java.awt.Color(0, 0, 204));
        jLabel2.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 255, 255));
        jLabel2.setText("Nome: ");

        nomeTxt.setBackground(new java.awt.Color(0, 0, 204));
        nomeTxt.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        nomeTxt.setForeground(new java.awt.Color(0, 255, 255));
        nomeTxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                nomeTxtFocusLost(evt);
            }
        });
        nomeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nomeTxtKeyReleased(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 255));
        jLabel3.setText("Idade: ");

        idadeTxt.setBackground(new java.awt.Color(0, 0, 204));
        idadeTxt.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        idadeTxt.setForeground(new java.awt.Color(0, 255, 255));
        idadeTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                idadeTxtKeyReleased(evt);
            }
        });

        botaoConfirmar.setBackground(new java.awt.Color(0, 0, 204));
        botaoConfirmar.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        botaoConfirmar.setForeground(new java.awt.Color(0, 255, 255));
        botaoConfirmar.setText("Confirmar");
        botaoConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoConfirmarActionPerformed(evt);
            }
        });
        botaoConfirmar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botaoConfirmarKeyReleased(evt);
            }
        });

        botaoFechar.setBackground(new java.awt.Color(0, 0, 204));
        botaoFechar.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        botaoFechar.setForeground(new java.awt.Color(0, 255, 255));
        botaoFechar.setText("Fechar");
        botaoFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoFecharActionPerformed(evt);
            }
        });

        labelVariavel1.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        labelVariavel1.setForeground(new java.awt.Color(0, 255, 255));
        labelVariavel1.setText("Informe ...: ");

        alergiaSalarioCpfTxt.setBackground(new java.awt.Color(0, 0, 204));
        alergiaSalarioCpfTxt.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        alergiaSalarioCpfTxt.setForeground(new java.awt.Color(0, 255, 255));
        alergiaSalarioCpfTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                alergiaSalarioCpfTxtKeyReleased(evt);
            }
        });

        musicaCargaHTxt.setBackground(new java.awt.Color(0, 0, 204));
        musicaCargaHTxt.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        musicaCargaHTxt.setForeground(new java.awt.Color(0, 255, 255));
        musicaCargaHTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                musicaCargaHTxtKeyReleased(evt);
            }
        });

        labelVariavel2.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        labelVariavel2.setForeground(new java.awt.Color(0, 255, 255));
        labelVariavel2.setText("Informe ...: ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(botaoConfirmar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botaoFechar))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(nomeTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(idadeTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(musicaCargaHTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(labelVariavel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(alergiaSalarioCpfTxt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)))
                        .addGap(0, 76, Short.MAX_VALUE))
                    .addComponent(labelVariavel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(nomeTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(idadeTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(labelVariavel1)
                .addGap(18, 18, 18)
                .addComponent(alergiaSalarioCpfTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(labelVariavel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(musicaCargaHTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botaoConfirmar)
                    .addComponent(botaoFechar))
                .addContainerGap())
        );

        tabelaPerfis.setFont(new java.awt.Font("Bahnschrift", 0, 17)); // NOI18N
        tabelaPerfis.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabelaPerfis);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 618, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void nomeTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomeTxtKeyReleased

        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
    }//GEN-LAST:event_nomeTxtKeyReleased

    private void idadeTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idadeTxtKeyReleased

        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
    }//GEN-LAST:event_idadeTxtKeyReleased

    private void botaoConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoConfirmarActionPerformed

        if (usuario == 1) {

            if (!usuarioLogado.getTipoUsuario().equalsIgnoreCase("gerente")) {

                JOptionPane.showMessageDialog(this, "Somente o gerente pode cadastrar funcionarios!!!", "Faça login como gerente!", JOptionPane.ERROR_MESSAGE);
                botaoFechar.doClick();
                return;

            }

        }

        this.nome = nomeTxt.getText();
        this.idade = Integer.parseInt(idadeTxt.getText());

        Usuario usuarioLogado = Login.retornaUsuarioLogado();

        switch (usuario) {

            case 0:

                this.alergiasSalarioCpf = alergiaSalarioCpfTxt.getText();
                this.musicaCarga = musicaCargaHTxt.getText();

                Cliente novoCliente = new Cliente(alergiasSalarioCpf, musicaCarga, nome, idade, usuarioLogado.getSenha(), usuarioLogado.getEmail(), tipoUsuario);
                ClienteDAO.inserirCliente(novoCliente);

                break;

            case 1:

                this.alergiasSalarioCpf = alergiaSalarioCpfTxt.getText();
                this.musicaCarga = musicaCargaHTxt.getText();

                Funcionario novoFuncionario = new Funcionario(Double.parseDouble(this.alergiasSalarioCpf), Double.parseDouble(this.musicaCarga), nome, idade, usuarioLogado.getSenha(), usuarioLogado.getEmail(), tipoUsuario);
                FuncionarioDAO.inserirFuncionario(novoFuncionario);

                break;

            default:

                this.alergiasSalarioCpf = alergiaSalarioCpfTxt.getText();
                boolean valido = verificaCPF(alergiasSalarioCpf);

                if (valido) {
                        
                    Gerente novoGerente = new Gerente(this.alergiasSalarioCpf, nome, idade, usuarioLogado.getSenha(), usuarioLogado.getEmail(), tipoUsuario);
                    GerenteDAO.inserirGerente(novoGerente);

                }else{
                        
                    JOptionPane.showMessageDialog(this, "Informe um CPF válido!!!", "CPF inválido!", JOptionPane.ERROR_MESSAGE);
                    return;
                        
                }

                break;

        }

        if (this.usuarioLogado.getSenha().equals("") || this.usuarioLogado.getEmail().equals("")) {

            JOptionPane.showMessageDialog(this, "Preencha todos os campos!!!", "Preencha os campos!", JOptionPane.ERROR_MESSAGE);

        }

        Usuario novoUsuario = new Usuario(usuarioLogado.getCodigo(), nome, idade, usuarioLogado.getSenha(), usuarioLogado.getEmail(), tipoUsuario);
        UsuarioDAO.updateUsuario(novoUsuario);
        /*UsuarioDAO.inserirPerfil(novoUsuario);
        UsuarioDAO.deletaUsuario(usuarioLogado);*/
        botaoFechar.doClick();
    }//GEN-LAST:event_botaoConfirmarActionPerformed

    private void botaoFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoFecharActionPerformed

        this.framePai.trocarPainel(null);
        this.framePai.setSize(940, 672);

    }//GEN-LAST:event_botaoFecharActionPerformed

    private void alergiaSalarioCpfTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_alergiaSalarioCpfTxtKeyReleased

        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
    }//GEN-LAST:event_alergiaSalarioCpfTxtKeyReleased

    private void musicaCargaHTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_musicaCargaHTxtKeyReleased

        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
    }//GEN-LAST:event_musicaCargaHTxtKeyReleased

    private void nomeTxtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_nomeTxtFocusLost

        this.nome = nomeTxt.getText();

        if (nome.equals("") || nome == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de nome!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }

    }//GEN-LAST:event_nomeTxtFocusLost

    private void botaoConfirmarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botaoConfirmarKeyReleased

        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }

    }//GEN-LAST:event_botaoConfirmarKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField alergiaSalarioCpfTxt;
    private javax.swing.JButton botaoConfirmar;
    private javax.swing.JButton botaoFechar;
    private javax.swing.JTextField idadeTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelVariavel1;
    private javax.swing.JLabel labelVariavel2;
    private javax.swing.JTextField musicaCargaHTxt;
    private javax.swing.JTextField nomeTxt;
    private javax.swing.JTable tabelaPerfis;
    // End of variables declaration//GEN-END:variables
}
