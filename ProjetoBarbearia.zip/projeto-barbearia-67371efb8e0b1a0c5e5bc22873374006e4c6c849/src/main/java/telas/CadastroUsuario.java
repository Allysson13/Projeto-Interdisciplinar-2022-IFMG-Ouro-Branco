package telas;

import controller.RegraTabelaUsuario;
import repository.UsuarioDAO;
import modelos.Usuario;
import java.awt.Color;
import java.util.Vector;
import javax.swing.JOptionPane;

public class CadastroUsuario extends javax.swing.JPanel {

    private FramePrincipal framePai;
    private String email;
    private String senha;
    private RegraTabelaUsuario minhasRegras;

    public CadastroUsuario(FramePrincipal pai) {
        
        initComponents();
        
        areaTxt.setEnabled(false);
        
        this.minhasRegras = new RegraTabelaUsuario();
        tabelaUsuario.setModel(this.minhasRegras);
        
        this.framePai = pai;
       
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        botaoConfirmar = new javax.swing.JButton();
        botaoFechar = new javax.swing.JButton();
        fieldEmail = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaTxt = new javax.swing.JTextArea();
        fieldSenha = new javax.swing.JPasswordField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelaUsuario = new javax.swing.JTable();

        setBackground(new java.awt.Color(0, 51, 102));

        jPanel2.setBackground(new java.awt.Color(0, 51, 153));

        botaoConfirmar.setBackground(new java.awt.Color(0, 0, 204));
        botaoConfirmar.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        botaoConfirmar.setForeground(new java.awt.Color(0, 255, 255));
        botaoConfirmar.setText("Confirmar");
        botaoConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoConfirmarActionPerformed(evt);
            }
        });
        botaoConfirmar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botaoConfirmarKeyReleased(evt);
            }
        });

        botaoFechar.setBackground(new java.awt.Color(0, 0, 204));
        botaoFechar.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        botaoFechar.setForeground(new java.awt.Color(0, 255, 255));
        botaoFechar.setText("Fechar");
        botaoFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoFecharActionPerformed(evt);
            }
        });
        botaoFechar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botaoFecharKeyReleased(evt);
            }
        });

        fieldEmail.setBackground(new java.awt.Color(0, 0, 204));
        fieldEmail.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        fieldEmail.setForeground(new java.awt.Color(0, 0, 0));
        fieldEmail.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fieldEmailFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldEmailFocusLost(evt);
            }
        });
        fieldEmail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldEmailKeyReleased(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Bahnschrift", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 255));
        jLabel1.setText("Cadastro de Usuário");

        jLabel2.setBackground(new java.awt.Color(0, 0, 204));
        jLabel2.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 255, 255));
        jLabel2.setText("E-mail: ");

        jLabel3.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 255));
        jLabel3.setText("Senha: ");

        areaTxt.setBackground(new java.awt.Color(0, 0, 204));
        areaTxt.setColumns(20);
        areaTxt.setFont(new java.awt.Font("Bahnschrift", 0, 17)); // NOI18N
        areaTxt.setForeground(new java.awt.Color(0, 255, 255));
        areaTxt.setRows(5);
        areaTxt.setText("Bem-vindo a nossa barbearia, por favor \ninforme seu email e crie uma senha para \nrealizar o cadastro. \nAtenção: Crie uma senha com pelo menos \n8 dígitos, com letras maiúsculas e \nsímbolos.");
        jScrollPane1.setViewportView(areaTxt);

        fieldSenha.setBackground(new java.awt.Color(0, 0, 204));
        fieldSenha.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        fieldSenha.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fieldSenhaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldSenhaFocusLost(evt);
            }
        });
        fieldSenha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldSenhaKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(65, 65, 65))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(fieldEmail, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE)
                            .addComponent(fieldSenha))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(botaoConfirmar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(botaoFechar))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE))
                        .addContainerGap())))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(fieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(fieldSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botaoFechar)
                    .addComponent(botaoConfirmar))
                .addContainerGap())
        );

        tabelaUsuario.setFont(new java.awt.Font("Bahnschrift", 0, 17)); // NOI18N
        tabelaUsuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tabelaUsuario);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 498, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void botaoConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoConfirmarActionPerformed

        this.email = fieldEmail.getText();
        this.senha = new String(fieldSenha.getPassword());
        
        if (this.email.equals("") || this.senha.equals("")){
            
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!!!", "Preencha os campos!", JOptionPane.ERROR_MESSAGE);
            
        }

        if(this.senha.length() < 8){

            JOptionPane.showMessageDialog(this, "Cadastro Inválido, digite uma senha com mais de 8 dígitos!!!", "Situação de Cadastro", JOptionPane.ERROR_MESSAGE);
            fieldEmail.setBackground(Color.yellow);
            fieldSenha.setBackground(Color.yellow);

        }else if(!this.email.equals("") || !this.senha.equals("")){
            
            Vector<Usuario> consultaUsuario = UsuarioDAO.consultaUsuario();
            
            for(Usuario u : consultaUsuario){
                
                if(u.getEmail().equalsIgnoreCase(this.email)){
                    
                    JOptionPane.showMessageDialog(this, "O email informado já existe no sistema!!!", "Email de Cadastro", JOptionPane.ERROR_MESSAGE);
                    fieldEmail.setText("");
                    return;
                    
                }
                
            }
            
            Usuario novoUsuario = new Usuario(senha, email);
            UsuarioDAO.inserirUsuario(novoUsuario);
            JOptionPane.showMessageDialog(this, "Cadastro Válido", "Situação de Cadastro", JOptionPane.PLAIN_MESSAGE);
            Login login = new Login(framePai);
            Usuario usuarioLogado = login.retornaUsuarioPeloEmailESenha(novoUsuario.getEmail(), novoUsuario.getSenha());
            Login.defineUsuarioLogado(usuarioLogado);
            this.framePai.habilitaBotao();
            botaoFechar.doClick();

        }else{

            JOptionPane.showMessageDialog(this, "Cadastro Inválido, preencha os campos!!!", "Situação de Cadastro", JOptionPane.ERROR_MESSAGE);
            fieldEmail.setBackground(Color.yellow);
            fieldSenha.setBackground(Color.yellow);

        }

    }//GEN-LAST:event_botaoConfirmarActionPerformed

    private void botaoFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoFecharActionPerformed

        this.framePai.trocarPainel(null);
        this.framePai.setSize(940, 672);

    }//GEN-LAST:event_botaoFecharActionPerformed

    private void voltaCorOriginal(){
        
        fieldEmail.setBackground(Color.white);
        fieldSenha.setBackground(Color.white);
        
    }
    
    private void fieldEmailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldEmailFocusGained

        voltaCorOriginal();

    }//GEN-LAST:event_fieldEmailFocusGained

    private void fieldEmailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldEmailKeyReleased

        if(evt.getKeyChar() == '\n'){

            botaoConfirmar.doClick();

        }else if(evt.getKeyChar() == 27){

            botaoFechar.doClick();

        }

    }//GEN-LAST:event_fieldEmailKeyReleased

    private void fieldSenhaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldSenhaFocusGained
        
        voltaCorOriginal();
        
    }//GEN-LAST:event_fieldSenhaFocusGained

    private void fieldSenhaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldSenhaKeyReleased
        
        if(evt.getKeyChar() == '\n'){

            botaoConfirmar.doClick();

        }else if(evt.getKeyChar() == 27){

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldSenhaKeyReleased

    private void botaoConfirmarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botaoConfirmarKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }

    }//GEN-LAST:event_botaoConfirmarKeyReleased

    private void botaoFecharKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botaoFecharKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }

    }//GEN-LAST:event_botaoFecharKeyReleased

    private void fieldEmailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldEmailFocusLost
        
        this.email = fieldEmail.getText();
        
        if (email.equals("") || email == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de email!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldEmailFocusLost

    private void fieldSenhaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldSenhaFocusLost
        
        this.senha = new String(fieldSenha.getPassword());
        
        if (senha.equals("") || senha == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de senha!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldSenhaFocusLost


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaTxt;
    private javax.swing.JButton botaoConfirmar;
    private javax.swing.JButton botaoFechar;
    private javax.swing.JTextField fieldEmail;
    private javax.swing.JPasswordField fieldSenha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tabelaUsuario;
    // End of variables declaration//GEN-END:variables
}
