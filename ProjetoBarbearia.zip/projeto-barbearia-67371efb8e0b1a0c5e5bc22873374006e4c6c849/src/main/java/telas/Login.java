package telas;

import java.awt.Color;
import java.util.Vector;
import javax.swing.JOptionPane;
import modelos.Usuario;
import repository.UsuarioDAO;
import telas.FramePrincipal;

public class Login extends javax.swing.JPanel {

    public static FramePrincipal framePai;
    private String email;
    private String senha;
    private static Usuario usuarioLogado;

    public Login(FramePrincipal pai) {

        initComponents();
        
        this.framePai = pai;
        
        botaoSenha.setEnabled(false);

    }
    
    public static void defineUsuarioLogado(Usuario usuario){
        
        usuarioLogado = usuario;
        
    }

    public static Usuario retornaUsuarioLogado() {
        
        /*if(usuarioLogado == null){
            
            Login.framePai.trocarPainel(null);
            
        }*/
        
        return usuarioLogado;

    }

    private boolean verificaLogin() {

        Vector<Usuario> consultaUsuario = UsuarioDAO.consultaUsuario();

        for (Usuario u : consultaUsuario) {

            if (u.getEmail().equalsIgnoreCase(this.email) && u.getSenha().equals(this.senha)) {

                usuarioLogado = u;
                botaoSenha.setEnabled(true);
                return true;

            }
            
            if(u.getEmail().equalsIgnoreCase(this.email)){
                
                botaoSenha.setEnabled(true);
                
            }

        }

        return false;

    }
    
    public Usuario retornaUsuarioPeloEmailESenha(String email, String senha) {

        Vector<Usuario> consultaUsuario = UsuarioDAO.consultaUsuario();

        for (Usuario u : consultaUsuario) {

            if (u.getEmail().equalsIgnoreCase(email) && u.getSenha().equals(senha)) {
                
                return u;

            }

        }

        return null;

    }

    private void voltaCorOriginal() {

        fieldEmail.setBackground(Color.white);
        fieldSenha.setBackground(Color.white);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        fieldEmail = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        fieldSenha = new javax.swing.JPasswordField();
        botaoConfirmar = new javax.swing.JButton();
        botaoFechar = new javax.swing.JButton();
        botaoCadastro = new javax.swing.JButton();
        botaoSenha = new javax.swing.JButton();

        setBackground(new java.awt.Color(0, 51, 102));

        jLabel1.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 255));
        jLabel1.setText("Login");

        jLabel2.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 255, 255));
        jLabel2.setText("Informe o seu e-mail: ");

        fieldEmail.setBackground(new java.awt.Color(0, 0, 204));
        fieldEmail.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        fieldEmail.setText("@gmail.com");
        fieldEmail.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fieldEmailFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldEmailFocusLost(evt);
            }
        });
        fieldEmail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldEmailKeyReleased(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 255, 255));
        jLabel3.setText("Informe a sua senha: ");

        fieldSenha.setBackground(new java.awt.Color(0, 0, 204));
        fieldSenha.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        fieldSenha.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fieldSenhaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldSenhaFocusLost(evt);
            }
        });
        fieldSenha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldSenhaKeyReleased(evt);
            }
        });

        botaoConfirmar.setBackground(new java.awt.Color(0, 0, 204));
        botaoConfirmar.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        botaoConfirmar.setForeground(new java.awt.Color(0, 255, 255));
        botaoConfirmar.setText("Confirmar");
        botaoConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoConfirmarActionPerformed(evt);
            }
        });
        botaoConfirmar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botaoConfirmarKeyReleased(evt);
            }
        });

        botaoFechar.setBackground(new java.awt.Color(0, 0, 204));
        botaoFechar.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        botaoFechar.setForeground(new java.awt.Color(0, 255, 255));
        botaoFechar.setText("Fechar");
        botaoFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoFecharActionPerformed(evt);
            }
        });
        botaoFechar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botaoFecharKeyReleased(evt);
            }
        });

        botaoCadastro.setBackground(new java.awt.Color(0, 76, 110));
        botaoCadastro.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        botaoCadastro.setForeground(new java.awt.Color(0, 255, 51));
        botaoCadastro.setText("Cadastre-se");
        botaoCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoCadastroActionPerformed(evt);
            }
        });

        botaoSenha.setBackground(new java.awt.Color(0, 76, 110));
        botaoSenha.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        botaoSenha.setForeground(new java.awt.Color(0, 255, 51));
        botaoSenha.setText("Esqueceu a senha?");
        botaoSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoSenhaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 218, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(223, 223, 223))
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(botaoConfirmar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botaoFechar))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(botaoCadastro)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(jLabel2)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(fieldEmail, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
                                    .addComponent(fieldSenha)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addComponent(botaoSenha)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(23, 23, 23))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(fieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(fieldSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botaoConfirmar)
                    .addComponent(botaoFechar))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botaoCadastro)
                    .addComponent(botaoSenha))
                .addContainerGap(32, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void fieldEmailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldEmailFocusGained

        voltaCorOriginal();

    }//GEN-LAST:event_fieldEmailFocusGained

    private void fieldEmailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldEmailKeyReleased

        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }

    }//GEN-LAST:event_fieldEmailKeyReleased

    private void fieldSenhaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldSenhaFocusGained

        voltaCorOriginal();

    }//GEN-LAST:event_fieldSenhaFocusGained

    private void fieldSenhaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldSenhaKeyReleased

        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }

    }//GEN-LAST:event_fieldSenhaKeyReleased

    private void botaoConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoConfirmarActionPerformed

        this.email = fieldEmail.getText();
        this.senha = new String(fieldSenha.getPassword());

        if (this.senha.length() < 8) {

            JOptionPane.showMessageDialog(this, "Login inválido, digite uma senha com mais de 8 dígitos!!!", "Situação de Login", JOptionPane.ERROR_MESSAGE);
            fieldEmail.setBackground(Color.yellow);
            fieldSenha.setBackground(Color.yellow);

        } else if (!this.email.equals("") || !this.senha.equals("")) {

            //verifica login
            boolean login = verificaLogin();

            if (login) {

                JOptionPane.showMessageDialog(this, "Login válido! Prossiga...", "Resultado do Login", JOptionPane.PLAIN_MESSAGE);
                this.framePai.habilitaBotao();
                botaoFechar.doClick();

            } else {

                JOptionPane.showMessageDialog(this, "Login inválido!", "Resultado do Login", JOptionPane.ERROR_MESSAGE);

            }

        } else {

            JOptionPane.showMessageDialog(this, "Login Inválido, preencha os campos!!!", "Situação de Login", JOptionPane.ERROR_MESSAGE);
            fieldEmail.setBackground(Color.yellow);
            fieldSenha.setBackground(Color.yellow);

        }

    }//GEN-LAST:event_botaoConfirmarActionPerformed

    private void botaoFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoFecharActionPerformed

        this.framePai.trocarPainel(new Tabelas(usuarioLogado, this.framePai));
        this.framePai.setSize(940, 672);

    }//GEN-LAST:event_botaoFecharActionPerformed

    private void botaoCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoCadastroActionPerformed
        
        this.framePai.setSize(940, 520);
        this.framePai.trocarPainel(new CadastroUsuario(this.framePai));
        
    }//GEN-LAST:event_botaoCadastroActionPerformed

    private void botaoConfirmarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botaoConfirmarKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }

    }//GEN-LAST:event_botaoConfirmarKeyReleased

    private void botaoFecharKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botaoFecharKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }

    }//GEN-LAST:event_botaoFecharKeyReleased

    private void fieldEmailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldEmailFocusLost
        
        this.email = fieldEmail.getText();
        
        if (email.equals("") || email == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de email!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldEmailFocusLost

    private void fieldSenhaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldSenhaFocusLost
        
        this.senha = new String(fieldSenha.getPassword());
        
        if (senha.equals("") || senha == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de senha!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldSenhaFocusLost

    private void botaoSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoSenhaActionPerformed
        
        Vector<Usuario> consultaUsuario = UsuarioDAO.consultaUsuario();

        for (Usuario u : consultaUsuario) {

            if (u.getEmail().equalsIgnoreCase(this.email) ) {

                JOptionPane.showMessageDialog(this, "A senha cadastrada para o email: " + this.email + " é: " + u.getSenha(), "Senha Correta", JOptionPane.INFORMATION_MESSAGE);
                
            }

        }
        
    }//GEN-LAST:event_botaoSenhaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoCadastro;
    private javax.swing.JButton botaoConfirmar;
    private javax.swing.JButton botaoFechar;
    private javax.swing.JButton botaoSenha;
    private javax.swing.JTextField fieldEmail;
    private javax.swing.JPasswordField fieldSenha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
