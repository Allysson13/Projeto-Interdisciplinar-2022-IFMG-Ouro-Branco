package telas;

import controller.RegraTabelaEvento;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import modelos.Evento;
import repository.EventoDAO;

public class EventoPanel extends javax.swing.JPanel {
    
    private FramePrincipal framePai;
    private String nomeConvidados;
    private String fotografo;
    private Double duracao;
    private Timestamp data;
    private String cenario;
    private String alimentacao;
    private RegraTabelaEvento minhasRegras;
    private Date agora;

    public EventoPanel(FramePrincipal pai) {
        
        initComponents();
        
        this.framePai = pai;
        this.minhasRegras = new RegraTabelaEvento();
        tabelaEventos.setModel(minhasRegras);
        
        Calendar c = Calendar.getInstance();
        this.agora = c.getTime();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        fieldNomeConv = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        botaoFechar = new javax.swing.JButton();
        botaoConfirmar = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        fieldData = new javax.swing.JFormattedTextField();
        fieldHorario = new javax.swing.JFormattedTextField();
        fieldDuracao = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        fieldFotografo = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        fieldCenario = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        fieldAlimentacao = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaEventos = new javax.swing.JTable();

        setBackground(new java.awt.Color(0, 51, 102));
        setPreferredSize(new java.awt.Dimension(900, 500));

        jPanel4.setBackground(new java.awt.Color(0, 51, 153));

        jLabel11.setFont(new java.awt.Font("sansserif", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 255, 255));
        jLabel11.setText("Evento");

        jLabel12.setBackground(new java.awt.Color(0, 0, 204));
        jLabel12.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 255, 255));
        jLabel12.setText("Informe nome dos convidados: ");

        fieldNomeConv.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        fieldNomeConv.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldNomeConvFocusLost(evt);
            }
        });
        fieldNomeConv.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldNomeConvfieldNomeKeyReleased(evt);
            }
        });

        jLabel13.setBackground(new java.awt.Color(0, 0, 204));
        jLabel13.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 255, 255));
        jLabel13.setText("Informe a data do evento: ");

        jLabel14.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 255, 255));
        jLabel14.setText("Informe a duração do evento: ");

        botaoFechar.setBackground(new java.awt.Color(0, 0, 204));
        botaoFechar.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        botaoFechar.setForeground(new java.awt.Color(0, 255, 255));
        botaoFechar.setText("Fechar");
        botaoFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoFecharfecharBtnActionPerformed(evt);
            }
        });
        botaoFechar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botaoFecharfecharBtnKeyReleased(evt);
            }
        });

        botaoConfirmar.setBackground(new java.awt.Color(0, 0, 204));
        botaoConfirmar.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        botaoConfirmar.setForeground(new java.awt.Color(0, 255, 255));
        botaoConfirmar.setText("Confirmar");
        botaoConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoConfirmarbotaoConfirmarActionPerformed(evt);
            }
        });
        botaoConfirmar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                botaoConfirmarbotaoConfirmarKeyReleased(evt);
            }
        });

        jLabel15.setBackground(new java.awt.Color(0, 0, 204));
        jLabel15.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 255, 255));
        jLabel15.setText("Informe o horário do evento: ");

        try {
            fieldData.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        fieldData.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldDataFocusLost(evt);
            }
        });
        fieldData.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldDatafieldDataKeyReleased(evt);
            }
        });

        try {
            fieldHorario.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        fieldHorario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldHorarioFocusLost(evt);
            }
        });
        fieldHorario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldHorariofieldHorarioKeyReleased(evt);
            }
        });

        fieldDuracao.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        fieldDuracao.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldDuracaoFocusLost(evt);
            }
        });
        fieldDuracao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldDuracaofieldNomeKeyReleased(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 255, 255));
        jLabel16.setText("Informe o telefone do fotógrafo: ");

        fieldFotografo.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        fieldFotografo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldFotografoFocusLost(evt);
            }
        });
        fieldFotografo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldFotografofieldNomeKeyReleased(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 255, 255));
        jLabel17.setText("Informe o cenário do evento: ");

        fieldCenario.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        fieldCenario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldCenarioFocusLost(evt);
            }
        });
        fieldCenario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldCenariofieldNomeKeyReleased(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 255, 255));
        jLabel18.setText("Informe a comida do evento:");

        fieldAlimentacao.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        fieldAlimentacao.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fieldAlimentacaoFocusLost(evt);
            }
        });
        fieldAlimentacao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fieldAlimentacaofieldNomeKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(botaoConfirmar)
                        .addGap(94, 94, 94)
                        .addComponent(botaoFechar))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel14))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(fieldNomeConv, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel13))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel12))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(fieldHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(114, 114, 114)
                        .addComponent(jLabel11))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(fieldDuracao, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(fieldFotografo, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(fieldCenario, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(fieldData, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel15))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel16))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel17))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fieldAlimentacao, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18))))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(fieldNomeConv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(fieldData, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel15)
                .addGap(12, 12, 12)
                .addComponent(fieldHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(fieldDuracao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(fieldFotografo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(fieldCenario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(fieldAlimentacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botaoFechar)
                    .addComponent(botaoConfirmar))
                .addContainerGap())
        );

        tabelaEventos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabelaEventos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 572, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void fieldNomeConvfieldNomeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldNomeConvfieldNomeKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldNomeConvfieldNomeKeyReleased

    private void botaoFecharfecharBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoFecharfecharBtnActionPerformed
        
        this.framePai.trocarPainel(null);
        this.framePai.setSize(940, 672);
        
    }//GEN-LAST:event_botaoFecharfecharBtnActionPerformed

    private void botaoFecharfecharBtnKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botaoFecharfecharBtnKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_botaoFecharfecharBtnKeyReleased

    private void botaoConfirmarbotaoConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoConfirmarbotaoConfirmarActionPerformed
        
        this.nomeConvidados = fieldNomeConv.getText();
        
        SimpleDateFormat formatoData = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        
        try {

            Date data = (Date) formatoData.parse(fieldData.getText() + " " + fieldHorario.getText());
            this.data = new Timestamp(data.getTime());
            JOptionPane.showMessageDialog(this, this.data);
            
            Vector<Evento> consultaEvento = EventoDAO.consultaEvento();
            
            for(Evento a : consultaEvento){
                
                if(a.getData() == new Date(agora.getTime())){
                    
                    JOptionPane.showMessageDialog(this, "A data escolhida já está ocupada!!!", "Entrada da Data/Horario", JOptionPane.ERROR_MESSAGE);
                    return;
                    
                }
                
            }
            
            if(this.data.before(this.agora)){
                
                JOptionPane.showMessageDialog(this, "Informe um horário para o futuro!!!", "Entrada da Data", JOptionPane.ERROR_MESSAGE);
                return;
                
            }

        } catch (ParseException ex) {

            JOptionPane.showMessageDialog(this, "Erro na conversÃ£o para Data!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
        this.duracao = Double.parseDouble(fieldDuracao.getText());
        this.fotografo = fieldFotografo.getText();
        this.cenario = fieldCenario.getText();
        this.alimentacao = fieldAlimentacao.getText();
        
        Evento novoEvento = new Evento(nomeConvidados, fotografo, duracao, data, cenario, alimentacao);
        
        EventoDAO.inserirEvento(novoEvento);
        
        botaoFechar.doClick();
        
    }//GEN-LAST:event_botaoConfirmarbotaoConfirmarActionPerformed

    private void botaoConfirmarbotaoConfirmarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botaoConfirmarbotaoConfirmarKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_botaoConfirmarbotaoConfirmarKeyReleased

    private void fieldDatafieldDataKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldDatafieldDataKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldDatafieldDataKeyReleased

    private void fieldHorariofieldHorarioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldHorariofieldHorarioKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldHorariofieldHorarioKeyReleased

    private void fieldDuracaofieldNomeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldDuracaofieldNomeKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldDuracaofieldNomeKeyReleased

    private void fieldFotografofieldNomeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldFotografofieldNomeKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldFotografofieldNomeKeyReleased

    private void fieldCenariofieldNomeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldCenariofieldNomeKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldCenariofieldNomeKeyReleased

    private void fieldAlimentacaofieldNomeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fieldAlimentacaofieldNomeKeyReleased
        
        if (evt.getKeyChar() == '\n') {

            botaoConfirmar.doClick();

        } else if (evt.getKeyChar() == 27) {

            botaoFechar.doClick();

        }
        
    }//GEN-LAST:event_fieldAlimentacaofieldNomeKeyReleased

    private void fieldNomeConvFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldNomeConvFocusLost
        
        this.nomeConvidados = fieldNomeConv.getText();
        
        if (nomeConvidados.equals("") || nomeConvidados == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de nome dos convidados!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldNomeConvFocusLost

    private void fieldDataFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldDataFocusLost
        
        if (fieldData.getText().equals("") || fieldData.getText() == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de data!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldDataFocusLost

    private void fieldHorarioFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldHorarioFocusLost
        
        if (fieldHorario.getText().equals("") || fieldHorario.getText() == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de data!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldHorarioFocusLost

    private void fieldDuracaoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldDuracaoFocusLost
        
        this.duracao = Double.parseDouble(fieldDuracao.getText());
        
        if (duracao == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de duracao!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldDuracaoFocusLost

    private void fieldFotografoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldFotografoFocusLost
        
        this.fotografo = fieldFotografo.getText();
        
        if (fotografo.equals("") || fotografo == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de número do fotógrafo!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldFotografoFocusLost

    private void fieldCenarioFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldCenarioFocusLost
        
        this.cenario = fieldCenario.getText();
        
        if (cenario.equals("") || cenario == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de cenário!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldCenarioFocusLost

    private void fieldAlimentacaoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fieldAlimentacaoFocusLost
        
        this.alimentacao = fieldAlimentacao.getText();
        
        if (alimentacao.equals("") || alimentacao == null) {

            JOptionPane.showMessageDialog(this, "Preencha o campo de comida!!!", "Erro", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_fieldAlimentacaoFocusLost


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoConfirmar;
    private javax.swing.JButton botaoFechar;
    private javax.swing.JTextField fieldAlimentacao;
    private javax.swing.JTextField fieldCenario;
    private javax.swing.JFormattedTextField fieldData;
    private javax.swing.JTextField fieldDuracao;
    private javax.swing.JTextField fieldFotografo;
    private javax.swing.JFormattedTextField fieldHorario;
    private javax.swing.JTextField fieldNomeConv;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaEventos;
    // End of variables declaration//GEN-END:variables
}
