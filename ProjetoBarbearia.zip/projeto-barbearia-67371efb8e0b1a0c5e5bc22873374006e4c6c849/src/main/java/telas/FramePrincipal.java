package telas;

import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class FramePrincipal extends javax.swing.JFrame {

    //representa a área onde os componentes vão ser desenhados
    private Container conteudoFrame;

    public FramePrincipal() {

        initComponents();

        //configurar o frame para que os componentes ocupem todo o espaço
        this.setLayout(new BorderLayout());
        this.conteudoFrame = this.getContentPane();
        trocarPainel(new Login(this));
        this.setSize(540, 350);
        perfilMenu.setEnabled(false);
        agendamentoItem.setEnabled(false);
        eventoItem.setEnabled(false);
        tabelasItem.setEnabled(false);
        loginItem.setSelected(false);

    }
    
    public void validaLogin(){
        
        loginItem.setSelected(true);
        
    }
    
    public void inValidaLogin(){
        
        loginItem.setSelected(false); 
        
    }

    public void habilitaBotao() {

        perfilMenu.setEnabled(true);
        agendamentoItem.setEnabled(true);
        eventoItem.setEnabled(true);
        tabelasItem.setEnabled(true);

    }

    public void trocarPainel(JPanel painelNovo) {

        conteudoFrame.removeAll();

        if (painelNovo == null) {

            painelNovo = new Tabelas(Login.retornaUsuarioLogado(), this);
            this.setSize(940, 672);

        }

        //talvez o painel seja maior que o frame
        //entao vamos add barras de rolagem
        JScrollPane painelBarraRolagem = new JScrollPane(painelNovo);
        conteudoFrame.add(painelBarraRolagem);

        //refresh da UI (interface grafica)
        validate();

        //setando o painel como visivel
        setVisible(true);

        //render da tela como um todo
        conteudoFrame.repaint();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar2 = new javax.swing.JMenuBar();
        opcoesMenu = new javax.swing.JMenu();
        loginItem = new javax.swing.JCheckBoxMenuItem();
        cadastroItem = new javax.swing.JMenuItem();
        perfilMenu = new javax.swing.JMenu();
        clienteItem = new javax.swing.JMenuItem();
        funcionarioItem = new javax.swing.JMenuItem();
        gerenteItem = new javax.swing.JMenuItem();
        agendamentoItem = new javax.swing.JMenuItem();
        eventoItem = new javax.swing.JMenuItem();
        tabelasItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        opcoesMenu.setText("Opções");

        loginItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.ALT_DOWN_MASK));
        loginItem.setSelected(true);
        loginItem.setText("Login");
        loginItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginItemActionPerformed(evt);
            }
        });
        opcoesMenu.add(loginItem);

        cadastroItem.setText("Cadastro");
        cadastroItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastroItemActionPerformed(evt);
            }
        });
        opcoesMenu.add(cadastroItem);

        perfilMenu.setText("Criar Perfil");

        clienteItem.setText("Cliente");
        clienteItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clienteItemActionPerformed(evt);
            }
        });
        perfilMenu.add(clienteItem);

        funcionarioItem.setText("Funcionário");
        funcionarioItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                funcionarioItemActionPerformed(evt);
            }
        });
        perfilMenu.add(funcionarioItem);

        gerenteItem.setText("Gerente");
        gerenteItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gerenteItemActionPerformed(evt);
            }
        });
        perfilMenu.add(gerenteItem);

        opcoesMenu.add(perfilMenu);

        agendamentoItem.setText("Agendamento");
        agendamentoItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agendamentoItemActionPerformed(evt);
            }
        });
        opcoesMenu.add(agendamentoItem);

        eventoItem.setText("Evento");
        eventoItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eventoItemActionPerformed(evt);
            }
        });
        opcoesMenu.add(eventoItem);

        tabelasItem.setText("Tabelas");
        tabelasItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tabelasItemActionPerformed(evt);
            }
        });
        opcoesMenu.add(tabelasItem);

        jMenuBar2.add(opcoesMenu);

        setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 617, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginItemActionPerformed

        this.setSize(540, 350);

        this.trocarPainel(new Login(this));

    }//GEN-LAST:event_loginItemActionPerformed

    private void clienteItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clienteItemActionPerformed

        this.setSize(960, 600);

        this.trocarPainel(new CriarPerfil(this, 0));

    }//GEN-LAST:event_clienteItemActionPerformed

    private void funcionarioItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_funcionarioItemActionPerformed

        this.setSize(940, 600);

        this.trocarPainel(new CriarPerfil(this, 1));

    }//GEN-LAST:event_funcionarioItemActionPerformed

    private void gerenteItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gerenteItemActionPerformed

        this.setSize(935, 600);

        this.trocarPainel(new CriarPerfil(this, 2));

    }//GEN-LAST:event_gerenteItemActionPerformed

    private void cadastroItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastroItemActionPerformed

        this.setSize(980, 600);

        this.trocarPainel(new CadastroUsuario(this));

    }//GEN-LAST:event_cadastroItemActionPerformed

    private void agendamentoItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agendamentoItemActionPerformed

        this.setSize(922, 640);

        this.trocarPainel(new AgendamentoPanel(this));

    }//GEN-LAST:event_agendamentoItemActionPerformed

    private void eventoItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eventoItemActionPerformed
        
        this.setSize(922, 750);

        this.trocarPainel(new EventoPanel(this));
        
    }//GEN-LAST:event_eventoItemActionPerformed

    private void tabelasItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tabelasItemActionPerformed
        
        this.setSize(940, 672);
        this.trocarPainel(new Tabelas(Login.retornaUsuarioLogado(), this));
        
    }//GEN-LAST:event_tabelasItemActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FramePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FramePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FramePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FramePrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FramePrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem agendamentoItem;
    private javax.swing.JMenuItem cadastroItem;
    private javax.swing.JMenuItem clienteItem;
    private javax.swing.JMenuItem eventoItem;
    private javax.swing.JMenuItem funcionarioItem;
    private javax.swing.JMenuItem gerenteItem;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JCheckBoxMenuItem loginItem;
    private javax.swing.JMenu opcoesMenu;
    private javax.swing.JMenu perfilMenu;
    private javax.swing.JMenuItem tabelasItem;
    // End of variables declaration//GEN-END:variables
}
